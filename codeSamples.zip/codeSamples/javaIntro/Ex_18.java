// program to illustrate the use of threads
// based on Deitel text ex. 13.3

import java.io.*;
import java.util.*;

public class Ex_18  
{
	
	public static void main(String[] args)
	{
	   PrintThread thread1, thread2, thread3;	
           System.out.println("This is the main thread.\n");
           thread1 = new PrintThread ( "1");
           thread2 = new PrintThread ( "2");
           thread3 = new PrintThread ( "3");

           thread1.start();
           thread2.start();
           thread3.start();
	}
} // end class Ex_18

class PrintThread extends Thread{  

        // thread constructor

        public PrintThread ( String id )
        {
             super( id );
             System.out.println ("Thread " + id + "created\n");
        }

	public void run() // thread execution
	{
           System.out.println("Thread " + getName( ) + " here\n");
	}

} // end class PrintThread

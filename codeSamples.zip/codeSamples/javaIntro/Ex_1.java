
// based on Holmes example in  chap_6\ex_6.java
// program to demonstrate how to pass arguments to the main method

import java.io.*;

class Ex_1
{
	
	public static void main(String[] args) throws IOException
	{
		int numberOfArgs = args.length;

		for (int index=0; index != numberOfArgs; index++)
			System.out.println(args[index]);
	}
}

// chap_10\Ex_6.java
// program to demonstrate the construction of a container
// and mouse events

import java.awt.*;
import java.awt.event.*;

class Gui extends Frame implements WindowListener, MouseListener
{
	// constructor
	public Gui(String s)
	{
		super(s);
		setBackground(Color.yellow);
		addMouseListener(this);
		addWindowListener(this);
	}
	
	public void mouseClicked(MouseEvent event){}
	public void mouseEntered(MouseEvent event){}
	public void mouseExited(MouseEvent event){}	
	public void mouseReleased(MouseEvent event){}

	public void mousePressed(MouseEvent event)
	{
		// get coordinates of mouse
		int x = event.getX();
		int y = event.getY();

		Graphics g = getGraphics();
		
		// display message on screen
		g.drawString("+ ["+String.valueOf(x)+","+
			                String.valueOf(y)+"]",x,y);
	}
	
	public void windowClosed(WindowEvent event){}
	public void windowDeiconified(WindowEvent event){}
	public void windowIconified(WindowEvent event){}
	public void windowActivated(WindowEvent event){}
	public void windowDeactivated(WindowEvent event){}
	public void windowOpened(WindowEvent event){}

	public void windowClosing(WindowEvent event)
	{
		System.exit(0);
	}
}





class Ex_6
{
	public static void main(String[] args)
	{
		Gui screen = new Gui("Example 18");

		screen.setSize(400,300);
		screen.setVisible(true);
	}
}

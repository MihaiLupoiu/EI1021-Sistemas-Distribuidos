// chap_10\Ex_5.java
// program to mimic a calculator

import java.awt.*;
import java.awt.event.*;
import java.io.*;

class Calculator extends Frame implements ActionListener, WindowListener
{
	
	private TextField display = new TextField(10);
	private Button[] button = new Button[15];

	static String[] keys = {" 0 "," 1 "," 2 ",
								   " 3 "," 4 "," 5 ",
								   " 6 "," 7 "," 8 ",
								   " 9 "," + "," - ",
								   " = "," * "," / "};
	
	private StringBuffer registerA = new StringBuffer();
	private StringBuffer registerB = new StringBuffer();

	private char operator; 
	private boolean firstNumberAlreadyInput = false;

	//-------------------------------------------------------------------

	// constructor
	public Calculator(String s)
	{
		super(s);
		setBackground(Color.yellow);
		addWindowListener(this);

		// set up display
		setLayout(new FlowLayout(FlowLayout.CENTER));
		add(display);
		
		Panel keypad = new Panel();
		keypad.setLayout(new GridLayout(5,3));
		
		// set up keypad
		for (int index=0; index != 15; index++)
		{
			button[index] = new Button(keys[index]);
			button[index].addActionListener(this);
			keypad.add(button[index]);
		}
		add(keypad);
	}

	//-------------------------------------------------------------------

	public void windowClosed(WindowEvent event){}
	public void windowDeiconified(WindowEvent event){}
	public void windowIconified(WindowEvent event){}
	public void windowActivated(WindowEvent event){}
	public void windowDeactivated(WindowEvent event){}
	public void windowOpened(WindowEvent event){}
	public void windowClosing(WindowEvent event)
	{
		System.exit(0);
	}

	// method to detect which key has been pressed
	public void actionPerformed(ActionEvent event)
	{
		final int positionOfEqualsKey = 12;

		Object source = event.getActionCommand();

		// test for digit in the range 0-9
		for (int digit = 0; digit != 10; digit++)
		{
			if (source.equals(keys[digit]))
			{
				if (firstNumberAlreadyInput)
				{
					registerB.append(String.valueOf(digit));
					display.setText(registerB.toString());
					return;
				}
				else
				{
					registerA.append(String.valueOf(digit));
					display.setText(registerA.toString());
					return;
				}
			}
		}

		// test for an operator
		for (int positionOfOperator=10; positionOfOperator != 15;
					positionOfOperator++)
		{
			// test for +, -, * or /
			if (source.equals(keys[positionOfOperator]) && 
			   (positionOfOperator != positionOfEqualsKey))
			{
				operator = keys[positionOfOperator].charAt(1);
				firstNumberAlreadyInput = true;
				return;
			}
		}

		// test for =
		if (source.equals(" = "))
		{
			display.setText(doCalculation());
			registerA.setLength(0);
			registerB.setLength(0);		
			firstNumberAlreadyInput = false;
		}
	}

	





	private String doCalculation()
	{
		final char beep = '\u0007';

		try
		{
			int A = new Integer(registerA.toString()).intValue();
			int B = new Integer(registerB.toString()).intValue();
		
			switch (operator)
			{
				case '+' : return String.valueOf(A+B);
				case '-' : return String.valueOf(A-B);
				case '*' : return String.valueOf(A*B);
				default  : return String.valueOf(A/B);
			}
		}

		catch(Exception ae)
		{
			System.out.print(beep);
			return "   E R R O R";
		}
	}
}

//---------------------------------------------------------------------

class Ex_5
{
	public static void main(String[] args)
	{
		Calculator C = new Calculator("Example 17");

		C.setSize(150,200);
		C.setVisible(true);
	}
}

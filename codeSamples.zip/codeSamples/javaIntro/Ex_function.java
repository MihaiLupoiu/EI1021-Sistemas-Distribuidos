/***********************************************************
   Java program sample to illustrate the use of a static 
   method in the role of a "C-style function"
   Author: M. Liu
   Date:   1/11/01
***********************************************************/
public class Ex_function {

   public static void main (String[] args) {

      // invoke a void function
      func1("hi!" );
     
      // invokde a value returning function
      System.out.println(func2());
   
    } // end main

    static void func1(String aString) {
       System.out.println("You said: " + aString);
    } // end func1

    static String func2( ) {
       return ("func2 called");
    } // end func2

} // end class

     

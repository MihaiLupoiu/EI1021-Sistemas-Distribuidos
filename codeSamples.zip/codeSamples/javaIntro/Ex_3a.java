// Based on Holmes text chap_10\Ex_1.java
// program to demonstrate the construction of a container and a button

import java.awt.*;

class Gui extends Frame
{
	// constructor
	public Gui(String s)
	{
		super(s);
		setBackground(Color.black);
		setLayout(new FlowLayout());
		Button pushButton = new Button("press me");
		add(pushButton);
	}
}

class Ex_3a
{
	public static void main(String[] args)
	{
		Gui screen = new Gui("Example 1");

		screen.setSize(500,100);
		screen.setVisible(true);
	}
}

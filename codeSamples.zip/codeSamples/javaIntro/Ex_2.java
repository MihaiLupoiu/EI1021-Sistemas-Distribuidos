
// Based on Holmes chap_4 Ex_7
// program to read data from a file till the end of file, modify the
// information and write the information back to a different text file

import java.io.*;

class Ex_2
{
	public static void main(String[] args) throws IOException
	{
		final float RATE_OF_INFLATION = 0.025f;
		
		FileReader file1         = new FileReader("data.txt");
		BufferedReader inputFile = new BufferedReader(file1);		

		FileWriter file2         = new FileWriter("results.txt");
		PrintWriter outputFile   = new PrintWriter(file2);

		String name;
        String theLine;
		float oldprice, newprice;
		
               
		theLine = inputFile.readLine();
		while (theLine != null)  // while EOF has not been reached
		{
		    oldprice = new Float(theLine).floatValue();
			newprice = oldprice + (oldprice * RATE_OF_INFLATION);
			name = inputFile.readLine();
			outputFile.println(newprice + " " + name);
		    theLine = inputFile.readLine();
		}

		inputFile.close();
		outputFile.close();
	}
}

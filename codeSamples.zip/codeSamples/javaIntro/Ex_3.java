
// chap_10\Ex_3.java
// program to demonstrate action listeners and event handlers

import java.awt.*;
import java.awt.event.*;

class Gui extends Frame implements ActionListener
{
	// constructor
	public Gui(String s)
	{
		super(s);          // create a frame container
		setBackground(Color.red);
		setLayout(new FlowLayout());
		Button pushButton = new Button("press me");
                                   // create a button
		add(pushButton);
                                   // add button to container                   
		pushButton.addActionListener(this);
                                   // associate this Action 
                                   //  listener with the button
	}

        // the event handler
	public void actionPerformed(ActionEvent event)
	{
		final char bell = '\u0007';   // a constant for bell

		if (event.getActionCommand().equals("press me"))
		{
			System.out.print(bell);
		}
	}	
}

class Ex_3
{
	public static void main(String[] args)
	{
		Gui screen = new Gui("Example 3");

		screen.setSize(500,100);
		screen.setVisible(true);
	}
}

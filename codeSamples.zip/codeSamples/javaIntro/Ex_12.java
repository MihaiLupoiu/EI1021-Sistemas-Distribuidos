
// chap_10\Ex_12.java
// form program
// program to demonstrate a graphical user interface for form input     

import java.awt.*;
import java.awt.event.*;
import java.io.*;

class Form extends Frame implements 
		ActionListener,		// menu item
		WindowListener			// closing a window
{
   static TextField input = new TextField(20);

   String inputField = "0";

   public Form ( String s )
   {
      super ( s);
      setBackground ( Color.white);
      setForeground ( Color.blue);
      setLayout ( null );
        // no layout manager used

      Label l = new Label ("INPUT");

      l.setLocation ( 10, 40 ); l.setSize ( 100, 20 );

      add(l);

     input.setLocation ( 210, 35);  
     input.setSize ( 300, 30);

     add(input);

     input.addActionListener(this);
     addWindowListener(this);
   }// end form constructor

   public void actionPerformed (ActionEvent event)
   {
     Font font = new Font("Serif", Font.BOLD, 50);
     Graphics g = getGraphics ();
 
     // capture data
     inputField = new String(input.getText()); 
     g.setFont (font);
     g.setColor(Color.blue);
     g.drawString(inputField, 250, 150);
   } // end actionPerformed

   public void windowClosed (WindowEvent event) { }
   public void windowDeiconified (WindowEvent event) { }
   public void windowIconified (WindowEvent event) { }
   public void windowActivated (WindowEvent event) { }
   public void windowDeactivated (WindowEvent event) { }
   public void windowOpened (WindowEvent event) { }

   public void windowClosing (WindowEvent event) 
   {
     System.exit(0);
   }

} // end form class 

class Ex_12
{
    public static void main ( String[ ] args)
    {
       Form screen = new Form (" Example 12");
       screen.setSize (1000, 500);
       screen.setVisible (true);
    }
}

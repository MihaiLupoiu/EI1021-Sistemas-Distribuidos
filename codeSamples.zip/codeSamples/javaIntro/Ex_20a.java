// Based on Holmes
// chap_11\Ex_8.java
// applet to demonstrate the need for threads when
// continuously repainting a window

import java.applet.*;
import java.awt.*;
import java.util.*;

public class Ex_20a extends Applet
{
	Font font = new Font("Monospaced",Font.BOLD,16);

	int hours, mins, secs;
	
	// override the start method, to calculate the time of day
	// and call the repaint() method to display the time
	public void start()
	{
		while (true)
		{
			Calendar time=Calendar.getInstance();

			hours = time.get(Calendar.HOUR);
			mins = time.get(Calendar.MINUTE);
			secs = time.get(Calendar.SECOND);	

			repaint();
		}
	}
	
	// display the time of day on the screen
	public void paint(Graphics g)
	{
		g.setFont(font);
		g.drawString(String.valueOf(hours)+":"+
			          String.valueOf(mins)+":"+
					    String.valueOf(secs),50,50);
	}
}

// program to illustrate the use of threads
// based on Deitel text ex. 13.3

import java.io.*;
import Server;

public class Ex_18b  
{
	
	public static void main(String[] args)
	{
           Server theServer = new Server();
	   for (int i=0; i<100; i++) 
              theServer.showMessage(i + "");
	}
} // end class Ex_18b



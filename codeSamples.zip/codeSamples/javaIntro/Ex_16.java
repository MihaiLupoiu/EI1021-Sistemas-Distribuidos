
// chap_5\Ex_4.java
// program to input the size of a one-dimensional array;
// input numbers into the into the array and calculate
// and display the mean of the numbers

import java.io.*;

class Ex_16
{
	static BufferedReader keyboard = new 
			 BufferedReader(new InputStreamReader(System.in));
	
	static public void main(String[] args) throws IOException
	{
		int   sizeOfArray;
		int   sum = 0;
		float mean;
		
		System.out.print("How many numbers do you want to input? ");
		System.out.println.flush();
		sizeOfArray = new Integer(keyboard.readLine()).intValue();
		
		// declare the array
		int[] numbers = new int[sizeOfArray];
		
		// input numbers into the array
		System.out.println("\nInput " + sizeOfArray + " integers, one per line\n");
		for (int index=0; index != sizeOfArray; index++)
		{
			System.out.print("cell " + index + " "); System.out.println.flush();
			numbers[index] = new Integer(keyboard.readLine()).intValue();
		}

		// calculate the sum of the numbers in the array
		for (int index=0; index != sizeOfArray; index++)
			sum = sum + numbers[index];

		// calculate the arithmetic mean of the numbers
		mean = (float)sum/(float)sizeOfArray;
		
		System.out.println("\nMean of numbers in the array is " + mean);
	}
}

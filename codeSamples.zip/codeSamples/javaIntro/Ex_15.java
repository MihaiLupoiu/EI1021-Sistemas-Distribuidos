// chap_5\Ex_3.java
// program to input numbers into a one-dimensional array
// and display the largest number in the array

import java.io.*;

class Ex_15
{
	static BufferedReader keyboard = new 
			 BufferedReader(new InputStreamReader(System.in));
		

	static public void main(String[] args) throws IOException
	{
		// size of array
		final int SIZE = 5;

		int[] numbers = new int[SIZE];
		int largest;
		
		// input numbers into the array
		System.out.println.println("Input " + SIZE + " integers, one per line\n");
		for (int index=0; index != SIZE; index++)
		{
			System.out.println.print("cell " + index + " "); System.out.println.flush();
			numbers[index] = new Integer(keyboard.readLine()).intValue();
		}
		// find and output the largest number in the array
		largest = numbers[0];
		for (int index=1; index != SIZE; index++)
			if (numbers[index] > largest) largest = numbers[index];

		System.out.println("\nLargest number in the array is " + largest);
	}
}

// Holmes text
// chap_11\Ex_10.java
// applet to demonstrate three threads of execution;
// each thread makes different rates of progress in drawing a
// solid rectangle in its own window;
// the thread given less time to sleep will draw the longest
// rectangle compared with the thread that sleeps for longer periods
// of time

import java.applet.*;
import java.awt.*;

class Gui extends Frame
{
	static final int WIDTH_OF_FRAME     = 800;
	static final int HEIGHT_OF_FRAME    = 100;
	static final int INCREMENTAL_LENGTH = 5; // size rectangle increases
	static final int WIDTH_OF_RECTANGLE = 10;		 
	
	// unique ordinate position of top-left hand corner for each frame
	static int position = 0; 

	int lengthOfRectangle = 0; // initial length of rectangle

	//-------------------------------------------------------------------
	
	public Gui(String s)
	{
		super(s);
		// set up attributes of a single frame
		setSize(WIDTH_OF_FRAME,HEIGHT_OF_FRAME);
		setLocation(100,position);
		position = position+100;
		setBackground(Color.yellow);		
	}

	//-------------------------------------------------------------------

	public void draw()
	// method to draw a black rectangle in the frame
	{
		Graphics g = getGraphics();

		g.setColor(Color.black);
		lengthOfRectangle=lengthOfRectangle+INCREMENTAL_LENGTH;
		g.fillRect(10,50,lengthOfRectangle,WIDTH_OF_RECTANGLE);
	}
}

//---------------------------------------------------------------------

class GraphicThread extends Thread implements Runnable
{
	static final int DELAY = 5000; // maximum delay of 5 seconds
	int timeAsleep;	             // time a thread spend asleep	
	Gui threadFrame;               // the frame used by a thread
	public GraphicThread()
	{
		super();
		// calculate sleep time for thread 
		timeAsleep = (int)(DELAY*Math.random());
		
		// instantiate and set the attributes of a frame
		threadFrame = new 
		Gui("Thread sleeps for "+String.valueOf(timeAsleep)+" milliseconds");		
	}

	//----------------------------------------------------------------------
	// each thread will be scheduled an amount of time to run by the
	// operating system however some threads will remain asleep during 
	//	their allocated amount of time
	public void run()
	{
		while (true)
		{
			try{sleep(timeAsleep);} 
			catch(InterruptedException i){System.exit(1);}
			// set frame visible and extend length of rectangle
			threadFrame.setVisible(true);
			threadFrame.draw();
		}
	}
}

//------------------------------------------------------------------------

public class Ex_21 extends Applet
{
	GraphicThread firstThread, secondThread, thirdThread;	

	// override init() method to instantiate and start three threads
	public void init()
	{
		firstThread = new GraphicThread();
		secondThread = new GraphicThread();
		thirdThread = new GraphicThread();

		firstThread.start();
		secondThread.start();
		thirdThread.start();
	}

	//---------------------------------------------------------------------
	// override destroy() method to stop the three threads running
	public void destroy()
	{
		firstThread.stop();
		secondThread.stop();
		thirdThread.stop();
	}
}

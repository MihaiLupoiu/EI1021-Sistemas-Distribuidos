// The Server class provides a start m

import java.io.*;
import java.util.*;

public class Server  
{
        // null constructor
	public Server() {
        }

	public void showMessage(String s)
	{
	   PrintThread aThread;	
           
           aThread = new PrintThread (s);
           
           aThread.start();
           
	}
} // end class Ex_18

class PrintThread extends Thread{ 
        final int SLEEP_TIME = 1000;
        String theString;
        // thread constructor

        public PrintThread (String s )
        {
             
           super();
           theString = s;

        }

	public void run() // thread execution
	{
           for (int i=0; i<10; i++)
           System.out.println(theString);
           try {
             Thread.sleep( SLEEP_TIME );
           }
           catch ( InterruptedException exception ) {
           System.err.println( exception.toString() );
           }

	}

} // end class PrintThread

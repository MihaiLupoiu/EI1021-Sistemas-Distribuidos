

// Based on the Holmes text
// chap_11\prob_32
// applet to display a line moving down vertically, in alternating
// colors

import java.applet.*;
import java.awt.*;
import java.util.*;

public class Ex_19 extends Applet implements Runnable
{
    Thread appletThread1, appletThread2;	
    int length = 1;
    Color c = Color.blue;

    public  void start()  // applet's start( ) method
    {		
        if (appletThread1 == null)
        {
          appletThread1 = new Thread(this, "a");
          appletThread1.start( );
        }
        if (appletThread2 == null)
        {
          appletThread2 = new Thread(this, "b");
          appletThread2.start( );
        }
    }

    public void run()  // overrides Runnable's run( ) method
    {
      String executingThread = Thread.currentThread().getName();
      if (executingThread.equals("b"))
      {
        try{Thread.sleep(500);}
        catch(InterruptedException i) {System.exit(1);}
      }
      while (true)
      {
        if (executingThread.equals("a"))
          c = Color.blue;
        else if (executingThread.equals("b"))
          c = Color.red;
        repaint();
        length+= 10;
        try{Thread.sleep(1000);}
        catch(InterruptedException i) {System.exit(1);}
      }
    }

    public void stop()  // overrides Applet's stop( )
    {
      if (appletThread1 != null)
      {
        // appletThread1.stop();  deprecated
        appletThread1 = null;
      }
      if (appletThread2 != null)
      {
        // appletThread2.stop();  deprecated
        appletThread2 = null;
      }
    }

    public void paint(Graphics g)  // overrides Applet's paint()
                                   // in java.awt.Component class
    {
         g.setColor (c);
         g.drawLine(100, length, 500, length);
    }
}

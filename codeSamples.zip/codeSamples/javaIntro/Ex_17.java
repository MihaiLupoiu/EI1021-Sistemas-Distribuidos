
// chap_7\Ex_3.java
// program to read lines of text from a file and store the respective 
// tokens on each line as fields of records in a vector

import java.io.*;
import java.util.*;

class Record
{
	String name;
	int    month;
	int    day;
	int    year;
}

class Ex_17
{

	static public void main(String[] args) throws IOException, 
												 FileNotFoundException
	{
		FileReader file = new FileReader ("birthday.txt");
		StreamTokenizer inputStream = new StreamTokenizer(file);

		Record birthday;
		int    tokenType;
		Vector recordStore = new Vector();
	
		tokenType = inputStream.nextToken();
		while (tokenType != StreamTokenizer.TT_EOF)
		{
			birthday = new Record();
			birthday.name = inputStream.sval;     inputStream.nextToken();
			birthday.month=(int)inputStream.nval; inputStream.nextToken();
			birthday.day  =(int)inputStream.nval; inputStream.nextToken();
			birthday.year =(int)inputStream.nval; 
			recordStore.addElement(birthday);
			tokenType = inputStream.nextToken();
		}

		recordStore.trimToSize();
		int sizeOfVector = recordStore.size();

		// display fields of records stored in the vector
		for (int index=0; index != sizeOfVector; index++)	
		{
			birthday = (Record) recordStore.elementAt(index);
			System.out.println(birthday.name + "\t " +
						      birthday.month + " " + 
						      birthday.day + " " + 
						      birthday.year);
		}
	}	
}


// program to illustrate keyboard input and integer -> string conversion

   import java.io.*;

class Ex_0
{
	
	public static void main(String[] args) throws IOException
	{
           String s;
           int number;
           BufferedReader keyboard =
              new BufferedReader (new InputStreamReader(System.in));
           System.out.println.println( "Enter an integer now: ");
           
           number = new Integer(keyboard.readLine( )).intValue();
           // Integer is a wrapper class over int
           // the statement above is a compact way of writing the
           // following code:
           // s = keyboard.readLine( );   
           // Integer someInteger = new Integer(s);
           // number = someInteger.intValue();

           number++;
           s = String.valueOf ( number );
           System.out.println( "input incremented yields " + s);
	}
}

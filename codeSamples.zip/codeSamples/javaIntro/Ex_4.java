// chap_10\Ex_4.java
// lists and text areas - Ben's Breakfast Bar

import java.awt.*;
import java.awt.event.*;

class Gui extends Frame implements ActionListener, WindowListener 
{
	static final int NUMBER_OF_MENU_ITEMS = 10;
		
	List      menu = new List(NUMBER_OF_MENU_ITEMS, true);
	TextArea  check = new TextArea();

	static String[] menuItems = {"Eggs",
								 "Blueberry Pancakes",
								 "Bagels with Cream Cheese",
								 "English Muffin",
								 "Yogurt",
								 "Corned Beef Hash",
								 "Toast",
								 "Fries",
								 "Tea or Coffee",
								 "Hot Chocolate"};

	static float[] menuPrices = {2.75f,4.00f,1.50f,0.95f,1.00f,
								 1.75f,0.75f,1.00f,0.75f,0.95f};

	//-----------------------------------------------------------------

	public Gui(String s)
	{
		super(s);
		setBackground(Color.yellow);
		setLayout(null);

		// display label, menu and button
		Label menuLabel = new Label("SELECT ITEMS FROM MENU");
		menuLabel.setLocation(10,30);
		menuLabel.setSize(180,20);
		add(menuLabel);		
		setUpMenu();
		
		Button button = new Button("FINISHED SELECTING");
		button.setLocation(10,220);
		button.setSize(180,20);
		add(button);
		button.addActionListener(this);
		add(check);	
		addWindowListener(this);
	}

	//--------------------------------------------------------------------
	
	private void setUpMenu()
	// method to display menu on screen
	{
		for (int index=0; index != NUMBER_OF_MENU_ITEMS; index++)
		{
			StringBuffer item = new StringBuffer();

			menu.addItem(menuItems[index]+" $"+menuPrices[index]);
		}

		menu.setLocation(10,50);
		menu.setSize(180,170);
		add(menu);
		menu.addActionListener(this);
	}

	//--------------------------------------------------------------------

	private void displayCheck()
	// method to display order and costs
	{
		int[] listArray = menu.getSelectedIndexes();
		float localTax = 0.05f;
		float tax;
		float subTotal=0;
		float total;

		check.setLocation(200,30);
		check.setSize(200,240);
		
		// set the text area to non-edit mode
		check.setEditable(false);

		// calculate cost of meal
		for (int index=0; index != listArray.length; index++)
			subTotal = subTotal + menuPrices[listArray[index]];
			
		tax = twoDecimalPlaces(localTax*subTotal);
		total = twoDecimalPlaces(subTotal+tax);
		
		// display costs
		check.append("           BEN'S BREAKFAST BAR\n\n");
		check.append("-------------- You ordered -----------\n");
		for (int index=0; index != listArray.length; index++)
		{			
			check.append(menu.getItem(listArray[index])+"\n");
		}
		check.append("\n");
		check.append("SUB TOTAL\t$"+String.valueOf(subTotal)+"\n");
		check.append("TAX      \t\t$"+String.valueOf(tax)+"\n");
		check.append("TOTAL    \t\t$"+String.valueOf(total)+"\n\n");
		check.append("Thank you - Have a Nice Day\n\n");

		// reset list array
		for (int index=0; index != listArray.length; index++)
			menu.deselect(listArray[index]);
	}

	//-----------------------------------------------------------------
	
	private float twoDecimalPlaces(float number)
	// function to adjust a floating-point value to only
	// two decimal places with rounding
	{
		final float roundingFraction = 0.005f;	
		      float newNumber;

		number = number+roundingFraction;
		newNumber = (int)(100.0f * number);
		return newNumber/100.0f;
	}

	//-----------------------------------------------------------------

	public void windowClosed(WindowEvent event){}
	public void windowDeiconified(WindowEvent event){}
	public void windowIconified(WindowEvent event){}
	public void windowActivated(WindowEvent event){}
	public void windowDeactivated(WindowEvent event){}
	public void windowOpened(WindowEvent event){}

	public void windowClosing(WindowEvent event)
	{
		System.exit(0);
	}

	//----------------------------------------------------------------

	public void actionPerformed(ActionEvent event)
	{
		Object source = event.getActionCommand();

		if (source.equals("FINISHED SELECTING"))
		{
			displayCheck();
		}
	}
}

class Ex_4
{
	public static void main(String[] args)
	{
		Gui screen = new Gui("Example 13");
		Font f = new Font("SansSerf",Font.BOLD,11);

		screen.setFont(f);
		screen.setSize(410,300);
		screen.setVisible(true);
	}
}

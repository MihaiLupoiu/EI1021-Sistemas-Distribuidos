// Fig. 8.7: SubString.java
// This program demonstrates the String class substring methods.
import java.io.*;

class SubString { 
   
   public static void main(String[] args) throws IOException
   {
      String letters = "abcdefghijklmabcdefghijklm";
      // test substring methods
      System.out.println( "Substring from index 20 to end is " +
         "\"" + letters.substring( 20 ) + "\"" );

      System.out.println( "Substring from index 0 upto 6 is " +
         "\"" + letters.substring( 0, 6 ) + "\"" );
   }
}


// Deitel Fig. 8.9: StringMisc2.java
// This program demonstrates the String class replace,
// toLowerCase, toUpperCase, trim, toString, and toCharArray
// methods.
import java.io.*;

class StringMisc {

   
   public static void main(String[] args) throws IOException{
     String s1 = new String( "hello" ),
            s2 = new String( "GOOD BYE" ),
            s3 = new String( "   spaces   " );

      System.out.println ("Miscellaneous string methods\n");

      System.out.println( "s1 = " + s1 );

      System.out.println( "s2 = " + s2 );

      System.out.println( "s3 = " + s3 );

      // test method replace      
      System.out.println( "Replace 'l' with 'L' in s1: " +
                    s1.replace( 'l', 'L' ) );

      // test toLowerCase and toUpperCase
      System.out.println( "s1 after toUpperCase = " + 
                    s1.toUpperCase() );

      System.out.println( "s2 after toLowerCase = " +
                    s2.toLowerCase() );

      // test trim method
      System.out.println( "s3 after trim = \"" + s3.trim() + "\"");

      // test toString method
      System.out.println( "s1 = " + s1.toString() );

      // test toCharArray method
      char charArray[] = s1.toCharArray();
      System.out.println( "s1 as a character array = " );
      System.out.println( charArray );

      // use .equals to compare to strings, NOT ==
      if (s1.equals(s2))
        System.out.println("s1 and s2 contain the same character string");
   }
}

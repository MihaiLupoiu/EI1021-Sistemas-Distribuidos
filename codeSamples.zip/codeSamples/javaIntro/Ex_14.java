
// chap_10\Ex_13.java
// form program
// program to demonstrate an applet which obtains input                 

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.applet.*;

public class Ex_14 extends Applet implements 
		ActionListener		
{
   TextField inputField = new TextField(20);

   public void init ( )
   {
      setBackground ( Color.white);
      setForeground ( Color.blue);
   //   setLayout ( new FlowLayout(FlowLayout.CENTER));

      add ( new Label("INPUT"));
      add (inputField);
      inputField.addActionListener(this);
   }// end init( )

   public void actionPerformed (ActionEvent event)
   {
     Font font = new Font("Monospaced", Font.ITALIC, 50);
 
     // capture data
     String input = inputField.getText(); 

     Graphics g = getGraphics( );
     g.setFont (font);
     g.setColor(Color.blue);
     g.drawString(input, 75, 100);
   } // end actionPerformed
}

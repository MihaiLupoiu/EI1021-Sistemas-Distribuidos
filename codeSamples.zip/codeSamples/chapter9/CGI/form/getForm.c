/*  Author: M. L. Liu, based on NCSA CGI tutorial sample.
    This is the source code for getForm.cgi, for the simple 
    form example.  It is invoked from getForm.html, and 
    generates a dynamic web page which displays the name-value
    pairs obtained from the predecessor form (getForm.html).   
    This program uses the NCSA CGI library for processing a
    query string obtained via the GET method.
*/      
#include <stdio.h>
#ifndef NO_STDLIB_H
#include <stdlib.h>
#else
char *getenv();
#endif

typedef struct {
    char name[128];
    char val[128];
} entry;

void getword(char *word, char *line, char stop);
char x2c(char *what);
void unescape_url(char *url);
void plustospace(char *str);

main(int argc, char *argv[]) {
    entry entries[10000];
    register int x,m=0;
    char *cl;

    printf("Content-type: text/html%c%c",10,10);

    if(strcmp(getenv("REQUEST_METHOD"),"GET")) {
        printf("This script should be referenced 
                with a METHOD of GET.%c", 13);
        exit(1);
    }

    cl = getenv("QUERY_STRING");
    if(cl == NULL) {
        printf("No query information to decode.%c",13);
        exit(1);
    }
    for(x=0;cl[0] != '\0';x++) {
        m=x;
        getword(entries[x].val,cl,'&');
        plustospace(entries[x].val);
        unescape_url(entries[x].val);
        getword(entries[x].name,entries[x].val,'=');
    }
    printf("<BODY bgcolor=\"#CCFFCC\">");
    printf("<H2>This page is generated dynamically by getForm.cgi.</H2>");
    printf("<H1>Query Results</H1>");
    printf(
      "You submitted the following name/value pairs:",
      "<p>%c",10);
    printf("<ul>%c",10);

    for(x=0; x <= m; x++)
        printf("<li> <code>%s = %s</code>%c",
           entries[x].name, entries[x].val,10);
    printf("</BODY>");
    printf("</HTML>");
}

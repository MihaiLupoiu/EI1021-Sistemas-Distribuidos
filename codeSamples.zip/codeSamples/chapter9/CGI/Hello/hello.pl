# Hello.pl 
#   A simple Perl CGI script

print "Content-type: text/html\n\n";
print "<head>\n";
print "<title>Hello, World</title>\n";
print "</head>\n";
print "<body>\n";
print "<font color = blue>\n";
print "<h1>Hello, World</h1>\n";
print "</font>\n";
print "</body>\n";

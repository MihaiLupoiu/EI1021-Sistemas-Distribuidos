/* cookie.c - source code for cookie.cgi
   Author: M. L. Liu.
   This script, requested by cookie.html, creates a cookie
   for each name-value pair in the query string
*/ 

#include <stdio.h>
#ifndef NO_STDLIB_H
#include <stdlib.h>
#else
char *getenv();
#endif

#define MAX_ENTRIES 10000

typedef struct {
    char *name;
    char *val;
} entry;

char *makeword(char *line, char stop);
char *fmakeword(FILE *f, char stop, int *len);
char x2c(char *what);
void unescape_url(char *url);
void plustospace(char *str);

main(int argc, char *argv[]) {
    entry entries[MAX_ENTRIES];
    register int x,m=0;
    int cl;

    if(strcmp(getenv("REQUEST_METHOD"),"POST")) {
        printf("This script should be referenced with a 
                METHOD of POST.\n");
        exit(1);
    }
    cl = atoi(getenv("CONTENT_LENGTH"));

     for(x=0;cl && (!feof(stdin));x++) {
        m=x;
        entries[x].val = fmakeword(stdin,'&',&cl);
        plustospace(entries[x].val);
        unescape_url(entries[x].val);
        entries[x].name = makeword(entries[x].val,'=');
    }        

/* A Set-cookie header line is generated for each name-value 
   pair.  Each line creates a cookie with default attributes.
*/
   for (x=0; x<=m; x++)  
   { 
       printf("Set-cookie: %s=%s%c\n",
               entries[x].name, entries[x].val,'\0'); 
   }
/*** IMPORTANT: NO BLANKS BEFORE OR AFTER THE EQUAL SIGN ***/
/*** Set-cookie request must precede response header ***/
    printf("Content-type: text/html%c%c",10,10);
    printf("<form method = POST action = cookie2.cgi>\n");
    printf("<body bgcolor=\"#CCFFCC\">"); 
    printf("Press <input type =submit value =here> to 
          create the cookie\n");
    printf("</form>\n<hr></html>");
}

import java.net.*;
import java.io.*;

public class URLBrowser {

// An application which uses a URL object to retreive
// the text contents of a web page.
// These command line arguments are expected, in order: 
//    <host name of the HTTP server>
//    <port number of the HTTP server>
//    <full path to a web document on the server host>

   public static void main(String[] args) {
      if (args.length != 3)
        System.out.println
         ("This program requires 3 command line arguments");
      else {
         try {
  		      String host = args[0];
  		      String port = args[1].trim();
            String fileName = args[2].trim();
            String HTTPString = 
              "http://"+host+":"+port+"/"+fileName;
            URL theURL = new URL(HTTPString);

            InputStream inStream = theURL.openStream( );
            BufferedReader input = 
              new BufferedReader
                (new InputStreamReader(inStream));
            String response;         
            response = input.readLine();
            // read and display one line at a time
            while (response != null) {
              System.out.println(response);
              response = input.readLine();
            } //end while
         }
         catch (Exception ex) {
            System.out.println("ERROR : " + ex) ;
	         ex.printStackTrace(System.out);
	      } 
      }// end else
   }// end main 
} //end class

This folder contains sample program code which appears in
the chapters of the book:
  "Distributed Computing � Concepts and Applications�
   by M. L. Liu, published by Addison-Wesley, Inc.

The sample code that appear in each chapter is placed in
a sub-folder titled with that chapter.  There are chapters
in which no sample code appears.

With the folder for each chapter there may be sub-folders,
separating the sample code by topics.

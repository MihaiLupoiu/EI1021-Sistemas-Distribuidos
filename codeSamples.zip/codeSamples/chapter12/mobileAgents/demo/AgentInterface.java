// An interface for a transportable object
// representing a mobile agent.
// M. Liu 

import java.io.Serializable;

public interface AgentInterface extends Serializable {
    void execute();
}

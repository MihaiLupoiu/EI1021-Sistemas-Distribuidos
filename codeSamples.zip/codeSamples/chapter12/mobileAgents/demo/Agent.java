// An implementation of a mobile agent

import java.io.*;
import java.util.*;
import java.rmi.*;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

public class Agent implements AgentInterface {
  
    int  hostIndex;     // which host to visit next 
    String name;
    Vector hostList;    // the itinerary
    int RMIPort = 12345;

    public Agent(String myName, Vector theHostList, 
                 int theRMIPort ) {
          name = myName;
          hostList = theHostList; 
          hostIndex = 0;
          RMIPort = theRMIPort;
    }
 
    // This method defines the tasks that the mobile agent
    // is to perform once it has arrived at a server.
    public void execute() {
      String thisHost, nextHost;
      sleep (2);   // delay for visibility
      System.out.println("007 here!");
      thisHost = (String) hostList.elementAt(hostIndex);
      hostIndex++;
      if (hostIndex < hostList.size()) {
         // if there is another host to visit
         nextHost = (String) hostList.elementAt(hostIndex);  
         sleep (5);   // delay for for visibility 
         try {
            // Locate the RMI registry on the next host
            Registry registry = LocateRegistry.getRegistry
                                ("localhost", RMIPort);                                                   
            ServerInterface h = (ServerInterface) 
                              registry.lookup(nextHost);
            System.out.println("Lookup for " + nextHost + 
                        " at " + thisHost + " completed " );
            sleep (5);   // delay for visibility
            // Ask the server at the next host to receive 
            //   this agent
            h.receive(this);
         } // end try
         catch (Exception e) {
           System.out.println
             ("Exception in Agent execute: " + e);
         }
      } // end if
      else { //if all the stops have been made
         sleep (5);   // delay for visibility
         System.out.println("Agent 007 has come home");
         sleep (5);   // delay for 5 visibility
      }
    }

    // Method sleep suspends this object's execution for
    //   the specified numbe of seconds.
    static void sleep (double time ){
       try {
          Thread.sleep( (long) (time * 1000.0));
       }
       catch (InterruptedException e) {
          System.out.println ("sleep exception");
       }
    } // end sleep

} // end class Agent

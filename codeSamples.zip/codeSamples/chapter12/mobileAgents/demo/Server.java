// An implementation of an agent server
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.net.*;
import java.io.*;

public class Server extends UnicastRemoteObject 
                   implements ServerInterface{
  static int RMIPort = 12345;
  public Server() throws RemoteException {
    super();
  }
    
  public void receive(Agent h) throws RemoteException {
    sleep (3);   // delay for visibility
    System.out.println
       ("*****Agent" + h.name + " arrived." );
    h.execute();
  }

  public static void main(String args[]) {
    InputStreamReader is = new InputStreamReader(System.in);
    BufferedReader br = new BufferedReader(is);
    String s;
    String myName = "server" + args[0];
    try{
       System.setSecurityManager(new RMISecurityManager());
       Server h = new Server();
       Registry registry = 
         LocateRegistry.getRegistry(RMIPort);

       registry.rebind( myName, h);

       System.out.println("********************************");
       System.out.println("     Agent " + myName + " ready.");
       System.out.println("********************************");
    }// end try
    catch (RemoteException re) {
       System.out.println("Exception in AgentServer.main: "
                           + re);
    } // end catch
  } // end main

    // Method sleep suspends this object's execution for the      
    // specified number of seconds.
    static void sleep (double time ){
        try {
                Thread.sleep( (long) (time * 1000.0));
        }
        catch (InterruptedException e){
                System.out.println ("sleep exception");
        }
     } // end sleep
} // end class

//Client.java - client program for launching the mobile agent
//  M. Liu

import java.io.*;
import java.util.*;
import java.rmi.*;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

public class Client {
  static int RMIPort = 12345;
  public static void main(String args[]) {
        
  System.setSecurityManager(new RMISecurityManager());

     try {
        Registry registry = LocateRegistry.getRegistry
                            ("localhost",  RMIPort);                                         
        ServerInterface h = (ServerInterface) 
                            registry.lookup("server1");
        System.out.println
               ("Lookup for server1 completed " );
        System.out.println("***Have a good trip, " +
                           " agent 007.");

        Vector hostList = new Vector();
        hostList.addElement("server1");
        hostList.addElement("server2");
        hostList.addElement("server3");
        Agent a = new Agent("007", hostList, RMIPort);
        h.receive(a);
        System.out.println("***Nice job, agent 007");
     } 
     catch (Exception e) {
        System.out.println("Exception in main: " + e);
     }
  } //end main
} //end class

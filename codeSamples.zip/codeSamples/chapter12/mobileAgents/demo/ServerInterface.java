// Agent Server interface file - M. Liu
import java.rmi.*;

public interface ServerInterface extends Remote {

  public void receive(Agent h) 
     throws java.rmi.RemoteException;

}

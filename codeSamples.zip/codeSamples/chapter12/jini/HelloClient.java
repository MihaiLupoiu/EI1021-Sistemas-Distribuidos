// A simple Jini client
// M. Liu, based on a code sample from "Noel's Nuggets"

import net.jini.core.entry.*;
import net.jini.core.lookup.*; 
import net.jini.core.discovery.*;    
import net.jini.lookup.entry.*; 
import com.sun.jini.lookup.*;
import java.rmi.*;

   class HelloClient{
      public static void main (String[] args){

        Entry[] attributes;
        LookupLocator lookup;  
        ServiceID id;       
        ServiceRegistrar registrar;
        ServiceTemplate template;
        HelloServerInterface helloServer;

        try {
          System.setSecurityManager 
             (new RMISecurityManager ());

          // Locate the Jini lookup service */           
          lookup = new LookupLocator("jini://localhost");
          // Find the ServiceRegistrar
          registrar  = lookup.getRegistrar();  
          // Look up the service           
          attributes = new Entry[1];
          attributes[0] = new Name ("HelloServer");
          template = new ServiceTemplate 
                        (null, null, attributes);
          helloServer = (HelloServerInterface) 
                           registrar.lookup(template);
          //Invoke a method of the service
          System.out.println(helloServer.sayHello());    
        } 
   
        catch (Exception ex) {
           ex.printStaceTrace( );
        }
      }
   }

// A simple Jini server
// M. Liu, based on a code sample from "Noel's Nuggets"
import net.jini.core.entry.*;
import net.jini.core.lookup.*;
import net.jini.core.discovery.*;
import net.jini.lookup.entry.*;
import com.sun.jini.lookup.*;
import com.sun.jini.lease.*;
import java.io.*;
import java.rmi.*;
import java.rmi.server.*;

   public class HelloServer extends UnicastRemoteObject 
      implements HelloServerInterface, ServiceIDListener {

      public HelloServer () throws RemoteException {
        super();
      }

      public String sayHello () throws RemoteException {
        return ("Hello World!");
      }

      // This method listens for the ServiceID returned
      // by the service directory when the ID is available.
      public void serviceIDNotify (ServiceID id)  {
        System.out.println (" ServiceID received: " + id);   
      }

      public static void main (String[] args){
        HelloServer server;
        Entry[] aeAttributes;
        JoinManager manager;

        try {   
           System.setSecurityManager 
              (new RMISecurityManager ());
           // Creates the attributes as an array of entry   
           // objects that describe this service, and register 
           // with the lookup service via The JoinManager. 
           // The service ID, when ready, will be reported
           // by the serviceID listener.
                
          attributes = new Entry[1];
          attributes[0] = new Name("HelloServer");
          server = new HelloServer();
          manager = new JoinManager (
            server, attributes,  server, 
            new LeaseRenewalManager()
          ); 
        } 

        catch (Exception ex) {
           ex.printStackTrace( );
        }
    } //end main
} //end class

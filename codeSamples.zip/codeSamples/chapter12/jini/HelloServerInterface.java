// Interface for the HelloServer

import java.rmi.*;

   public interface HelloServerInterface extends Remote {
      public String sayHello() throws RemoteException;
   }
} 

// A JavaSpaces Entry class for a space object
// M. Liu, based on code samples provided in:
// JAVASPACES PRINCIPLES, PATTERNS, AND PRACTICE, 
// Freeman, et al, Addison-Wesley Publishing Co 
//  (http://java.sun.com/docs/books/jini/javaspaces/)

import net.jini.core.entry.Entry;

public class SpaceObject implements Entry {
    public String message;
    public Integer counter; //An object is required.

    public SpaceObject( ) {
    }

    public SpaceObject(String message) {
        this.message = message;
        counter = 0;
    }

    public String toString( ) {
        return content + " read " + counter + " times.";
    }

    public void increment( ) {
        counter = new Integer(counter.intValue() + 1);
    }
} //end class

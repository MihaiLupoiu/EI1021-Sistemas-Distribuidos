This set of files is a simple code sample illustrating
the use of JavaSpaces, based on an example provided 
in:
 JAVASPACES PRINCIPLES, PATTERNS, AND PRACTICE, 
 Freeman, et al, Addison-Wesley Publishing Co 
 (http://java.sun.com/docs/books/jini/javaspaces/)

// A program which initaties a JavaSpaces entry.
// M. Liu, based on an code samples provided  in:
// JAVASPACES PRINCIPLES, PATTERNS, AND PRACTICE, 
// Freeman, et al, Addison-Wesley Publishing Co 
// (http://java.sun.com/docs/books/jini/javaspaces/)

import net.jini.core.lease.Lease;
import net.jini.space.JavaSpace;

public class HelloWorld {
   public static void main(String[] args) {
       try {
          SpaceObject msg = new SpaceObject("Hello World!");

          JavaSpace space;
          space = (JavaSpace)space();
          space.write(msg, null, Lease.FOREVER);

          SpaceObject template = new SpaceObject();
          while (true) {
             SpaceObject result = (SpaceObject)
                space.read(template, null, Long.MAX_VALUE);
             System.out.println(result);
             Thread.sleep(1000);
          } //end while
       } 
       catch (Exception ex) {
            ex.printStackTrace();
       }
    }
} //end class

// A client program which accesses a JavaSpaces entry.
// M. Liu, based on code samples provided  in:
// JAVASPACES PRINCIPLES, PATTERNS, AND PRACTICE, 
// Freeman, et al, Addison-Wesley Publishing Co 
// (http://java.sun.com/docs/books/jini/javaspaces/)

import net.jini.core.lease.Lease;
import net.jini.space.JavaSpace;

public class HelloWorldClient {    
   public static void main(String[] args) {
      try {
         JavaSpace space = (JavaSpace)space();           
         SpaceObject template = new SpaceObject();
         // Repeatedly retrieve the object from the space,
         // update it, then deposit the object in the space
         while (true) {
            // Read the object from the space.
            SpaceObject result = (SpaceObject)
               space.take(template, null, Long.MAX_VALUE);
            result.increment();
            // Write the object to the space
            space.write(result, null, Lease.FOREVER);
            Thread.sleep(1000);
         }//end while
      } 
      catch (Exception ex) {
           ex.printStackTrace();
      }
   }
} //end class

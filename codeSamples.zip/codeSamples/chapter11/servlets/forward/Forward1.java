import javax.servlet.*;
// Souce code for Cart servlet invoked when the
// web form cart.html is submitted
// M. Liu

import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class Forward1 extends HttpServlet
{
   public void doPost(HttpServletRequest request, 
     HttpServletResponse response)
     throws ServletException, IOException
   {
  
	   String url="HelloWorldExample";
            // Assuming that the HelloWorldExample.class file is 
            // in the same directory as this servlet's .class file.
       response.sendRedirect(url);               
           
   } //end doPost
   
   public void doGet(HttpServletRequest request, 
     HttpServletResponse response)
     throws ServletException, IOException
   {   
         doPost(request, response);
   }
} //end class

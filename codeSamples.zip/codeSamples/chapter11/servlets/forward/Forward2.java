import javax.servlet.*;
// This servlet forwards to the HelloWorld servlet using the
// forward method of the RequestDispatcher.
// M. Liu

import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class Forward2 extends HttpServlet
{
   public void doPost(HttpServletRequest request, 
     HttpServletResponse response)
     throws ServletException, IOException
   {
  
	   String url="/servlet/HelloWorldExample"";
            // Assuming that the HelloWorldExample.class file is 
            // in the same directory as this servlet's .class file.          
       ServletContext sc = getServletContext();
	   RequestDispatcher rd = sc.getRequestDispatcher(url);
	   rd.forward(request,response);             
           
   } //end doPost
   
   public void doGet(HttpServletRequest request, 
     HttpServletResponse response)
     throws ServletException, IOException
   {   
         doPost(request, response);
   }
} //end class

import javax.servlet.*;
// A controller servlet.  This servlet acts as a dispatcher for requests
// generated throughout a session.  It is assumed that each type of request is 
// tagged with a "submit" parameter with a unique value.  Depending on the
// value, this servlet forwards the request to the appropriate servlet.
// M. Liu

import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class Controller extends HttpServlet
{
   public void doPost(HttpServletRequest request, 
     HttpServletResponse response)
     throws ServletException, IOException
   {

	  String url = null;    
   	  String destiny = (request.getParameter("submit")).trim();
 
      if (destiny.equals("ONE"))        
	     url="/servlet/HelloWorldExample";
	  else
	  if (destiny.equals("TWO"))  
	     url="/servlet/RequestInfoExample";
	  else
	  if (destiny.equals("THREE"))  	  
	     url="/servlet/CookieExample";
	  ServletContext sc = getServletContext();
	  RequestDispatcher rd = sc.getRequestDispatcher(url);
	  rd.forward(request,response);  
          
   } //end doPost
   
   public void doGet(HttpServletRequest request, 
     HttpServletResponse response)
     throws ServletException, IOException
   {
      doPost(request, response);
   }
} //end class

A sample SOAP client application which
uses a SOAP method published on http://www.xmethods.com/
This is the apache SOAP client for the Currency Exchange
service, with slight modification.
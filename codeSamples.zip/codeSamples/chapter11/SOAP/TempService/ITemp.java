// A sample SOAP service object interface
// This method accepts a string containing a zip code,
// and returns the temperature of the area.

public interface ITemp 
{    
    float getTemp( String zipCode); 

} //end interface

A sample SOAP client-server package
  ITemp.java is an interface that defines
                 the remote method provided,
                 getTemp, for a simple service.
  Temp.java  is an implementation of the interface.
The service must be deployed on the host system
for it to be invoked by a client program.
  
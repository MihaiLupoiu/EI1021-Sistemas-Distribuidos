A sample SOAP client-server package
  IExchange.java is an interface that defines
                 the remote method provided,
                 getRate, for a simple service.
  Exchange.java  is an implementation of the interface.
  Client.java    is the client application
                 which invokes the getRate 
                 method.
  
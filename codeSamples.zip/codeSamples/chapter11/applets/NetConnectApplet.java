// A generic Applet
// When run in a browser or an appletviewer, it displays
// the string "Hello World"


import java.applet.Applet;
import java.awt.*;

import java.net.*;
import java.io.*;

public class NetConnectApplet extends Applet {
    public void paint(Graphics g) {
        Font myFont = new Font("Serif", Font.BOLD, 25);
        g.setColor(Color.red);
        g.drawString("Running an applet:", 50, 25);

        try {
           Socket socket;
           // attempt to make a network connection to www.alpha.edu
           socket = new Socket("www.alpha.edu", 80 );
           g.drawString("Opened a socket to www.csc.calpoly.edu port 80:", 
           50, 45);
//*
           // attempt to make a network connection to www.beta.edu
           socket = new Socket("www.beta.edu", 80 );
           g.drawString("Opened a socket to www.calpoly.edu port 80:", 
           50, 45);
//*/
        }
        catch (Exception ex)
        { 
            ex.printStackTrace( );
        }
         
    } //end paint
} //end class

// A generic Applet
// When run in a browser or an appletviewer, it displays
// the string "Hello World"


import java.applet.Applet;
import java.awt.*;

public class MyApplet extends Applet {
    public void paint(Graphics g) {
        Font myFont = new Font("Serif", Font.BOLD, 25);
        g.setColor(Color.red);
        g.drawString("Running an applet:", 50, 25);
    } //end paint
} //end class

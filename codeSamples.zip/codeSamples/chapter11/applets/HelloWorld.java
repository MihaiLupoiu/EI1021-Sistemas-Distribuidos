// The HelloWorld Applet
// When run in a browser or an appletviewer, it displays
// the string "Hello World"


import java.applet.Applet;
import java.awt.*;

public class HelloWorld extends Applet {
    public void paint(Graphics g) {

        g.drawString("Hello world!", 50, 25);
    } //end paint

} //end class

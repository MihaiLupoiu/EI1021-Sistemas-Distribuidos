/**************************************************
 *   A class which extends the Java Thread class.
 *   M. Liu       1/8/02
 *************************************************/

class SomeThread extends Thread {
   int myID;

   SomeThread(int id) {
      this.myID = id;
   }
 
   public void run() {
      int i;
      for (i = 1; i < 11; i++)
         System.out.println ("Thread"+myID + ": " + i);
   }
} //end class SomeThread

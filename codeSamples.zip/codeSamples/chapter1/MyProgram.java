/*******************************************************
 *  A sample of a simple Java application.
 *   M. Liu               1/8/02
 ******************************************************/

import java.io.*;

class MyProgram{
   
   public static void main(String[ ] args) 
      throws IOException{

      BufferedReader keyboard = new
         BufferedReader(new InputStreamReader(System.in));
      String theName;
      System.out.println("What is your name?");
      theName = keyboard.readLine( );
      System.out.print("Hello " + theName );
      System.out.println(" - welcome to CSC369.\n");

   } // end main

} //end class

// import SomeThread3;
public class RunThreads3
{
   public static void main (String[] args)
   {
     int originalThreadCount = Thread.activeCount( );
     for (int i=0; i<10; i++) {
     	Thread p = new Thread(new SomeThread3());
     	p.start();
	   System.out.println("thread count=" + Thread.activeCount( ));
     }

     while (Thread.activeCount() > originalThreadCount ){
         // loop until all child threads have exited.
     }
     System.out.println("finally, Count = " + SomeThread3.count);
   }
 }//end class RunThreads3


/*********************************************************
 *   A class which implements the Java Runnable interface.
 *   M. Liu       1/8/02
 *********************************************************/
class SomeThread2 implements Runnable {
   int myID;

   SomeThread2(int id) {
      this.myID = id;
   }
 
   public void run() {
      int i;
      for (i = 1; i < 11; i++)
        System.out.println ("Thread"+myID + ": " + i);
   }
} //end class SomeThread2


/*******************************************************
 *  A sample of a simple Java servlet.
 *   M. Liu               1/8/02
 ******************************************************/
import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class MyServlet extends HttpServlet {

   public void doGet (HttpServletRequest request, 
                      HttpServletResponse response)   
      throws ServletException, IOException { 

      PrintWriter out; 
      String title = "MyServlet Output"; 
      // set content type and other response header 
      //   fields first
      response.setContentType("text/html");
      // then write the data of the response 
      out = response.getWriter(); 
      out.println("<HTML><HEAD><TITLE>");
      out.println(title); 
      out.println("</TITLE></HEAD><BODY>"); 
      out.println("<H1>" + title +   "</H1>"); 
      out.println("<P>Hello World!"); 
      out.println("</BODY></HTML>"); 
      out.close();
   } //end doGet

} //end class


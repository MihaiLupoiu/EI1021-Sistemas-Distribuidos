/***************************************************
 *  A sample of a simple applet.
 *   M. Liu               1/8/02
 ***************************************************/

import java.applet.Applet;
import java.awt.*;

public class MyApplet extends Applet{

   public void paint(Graphics g){
      setBackground(Color.blue);

      Font Claude = new Font("Arial", Font.BOLD, 40);
      g.setFont(Claude);                                        
      g.setColor(Color.yellow);
      g.drawString("Hello World!", 100, 100);
   } // end paint

} //end class

package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import modelo.GestorConsultas;

/**
 * Servlet implementation class ServletCompraComic
 * Permite al cliente comprar un c�mic disponible de nuestra tienda.
 */
public class ServletBajaComic extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	// Gestor de consultas.
	private GestorConsultas gestor;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServletBajaComic() {
		super();
		// Abrimos un gestor de consultas.
		gestor = new GestorConsultas("Kirbys.kbs");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Obtenemos el c�digo introducido por el usuario
		int codigo = Integer.parseInt(request.getParameter("code"));
		// Intentamos vender y obtenemos los datos de c�mo ha ido la venta del c�mic
		String datosVenta = gestor.bajaComic(codigo);

		// Obtenemos la sesi�n asociada al cliente. Si no existe, creamos una.
		HttpSession session = request.getSession(true);
		// Intentamos obtener la lista de c�mics del objeto session.
		Vector<String> listaComics = (Vector<String>) session.getAttribute("comics");
		// Si no est� dicho atributo en la sesi�n lo creamos.
		if(listaComics == null) {
			listaComics = new Vector<String>();
			session.setAttribute("comics", listaComics);
		}
		
		String nombre = ComicStrings.getTitulo(datosVenta);

		// Fijamos el contenido de la p�gina web y escribimos la respuesta
		// en el objeto HttpServletResponse.
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println("<html>");
		out.println("<head>");
		out.println("<title>Compra de c�mics</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<p><table align=\"center\" cellpadding=\"10\">" +
				"<tr align=\"center\">" +
					"<td ><img src=\"kirby.jpg\" width=\"150\" height=\"150\"></td>" +
					"<td ><h1 style=\"text-align:center;\"> Kirby's Comics </h1></td>" +
				"</tr>" +
			"</table>");
		out.println("<h3 style=\"text-align:center;\">Compra del c�mic " + nombre + "</h3>");
		out.println("<ul>");
		// Si se ha logrado vender el c�mic...
		if(datosVenta.startsWith("[")) {
			float precio = ComicStrings.getPrecio(datosVenta);
			String autor = ComicStrings.getAutor(datosVenta);
			int stockRest = ComicStrings.getStockRestante(datosVenta);
			
			out.println("Enhorabuena, acaba de comprar un ejemplar del c�mic:</br>");
			out.println(nombre + " del autor " + autor + " a un precio de " + precio + " euros.</br>");
			out.println("</br>A�n nos quedan " + stockRest + " ejemplares en la tienda.");
			// A�adimos el comic comprado al carrito.
			listaComics.add(datosVenta);
		// Si no se ha logrado vender...
		} else if (datosVenta.contains("stock")) {
			out.println("Lo sentimos, no nos queda stock de este c�mic.");
		} else {
			out.println("Lo sentimos, no disponemos de este c�mic en la tienda.");
		}
		out.println("</ul>");
		out.println("<a href=\"ServletMuestraCarrito\">Mostrar carrito</a>");
		out.println("</br>");
		out.println("<a href=\"formularioBajaComic.html\">Compra otro c�mic</a>");
		out.println("</br>");
		out.println("<a href=\"index.html\">Volver a p�gina principal</a>");
		out.println("</body>");
		out.println("</html>");
	}
}

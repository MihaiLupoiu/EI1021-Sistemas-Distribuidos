package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ServletMuestraCarrito
 */
public class ServletMuestraCarrito extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServletMuestraCarrito() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Obtenemos la sesi�n asociada al cliente. Si no existe, creamos una.
		HttpSession session = request.getSession(true);

		// Intentamos obtener la lista de c�mics del objeto session.
		Vector<String> listaComics = (Vector<String>) session.getAttribute("comics");
		// Si no est� dicho atributo en la sesi�n lo creamos.
		if(listaComics == null) {
			listaComics = new Vector<String>();
			session.setAttribute("comics", listaComics);
		}

		// Fijamos el contenido de la p�gina web y escribimos la respuesta
		// en el objeto HttpServletResponse.
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Mi carrito de la compra</title>");
		out.println("</head>");
		
		out.println("<body>");
		out.println("<p><table align=\"center\" cellpadding=\"10\">" +
				"<tr align=\"center\">" +
					"<td ><img src=\"kirby.jpg\" width=\"150\" height=\"150\"></td>" +
					"<td ><h1 style=\"text-align:center;\"> Kirby's Comics </h1></td>" +
				"</tr>" +
			"</table>");
		out.println("<h3 style=\"text-align:center;\">Mi carrito de la compra</h3>");
		out.println("<p><table align=\"center\" cellpadding=\"10\">");
		//...
		if(listaComics.size() == 0) {
			// No hay compras.
			out.println("El cliente todav�a no ha realizado ninguna compra.");
		}
		else {
			float precioTotal = 0;
			// Listar compras.
			out.println(
					"<tr align=\"center\">" +
						//"<td ><img src=\"kirby.jpg\" width=\"150\" height=\"150\"></td>" +
						"<th > C�digo </th>" +
						"<th > T�tulo </th>" +
						"<th > Precio </th>" +
					"</tr>");
			for(String comic : listaComics) {
				float precio = ComicStrings.getPrecio(comic);
				precioTotal += precio;
				String nombre = ComicStrings.getTitulo(comic);
				String codigo = ComicStrings.getCodigo(comic);
				out.println(
							"<tr align=\"center\">" +
								//"<td ><img src=\"kirby.jpg\" width=\"150\" height=\"150\"></td>" +
								"<td >" + codigo + "</td>" +
								"<td >" + nombre + "</td>" +
								"<td >" + precio + " euros</td>" +
							"</tr>");
			}
			out.println("<tr> <td colspan=\"3\"> <hr> </td></tr>");
			out.println("<tr> <th colspan=\"2\"> Precio total: </th> <td> " + precioTotal + " euros </td></tr>");
		}
		out.println("</table>");
		out.println("<a href=\"formularioBajaComic.html\">Compra c�mic</a>");
		out.println("</br>");
		out.println("<a href=\"formularioAltaComic.html\">Vende c�mic</a>");
		out.println("</br>");
		out.println("<a href=\"index.html\">Volver a p�gina principal</a>");
		out.println("</body>");
		out.println("</html>");
	}
}
package controlador;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.GestorConsultas;

/**
 * Servlet implementation class ServletListarAutores
 */
public class ServletListarAutores extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	// Gestor de consultas.
	private GestorConsultas gestor;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletListarAutores() {
        super();
		// Abrimos un gestor de consultas.
        System.out.println("Inicializado gestor.");
		gestor = new GestorConsultas("Kirbys.kbs");
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String[] autores = gestor.listaAutores();
		
    	response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Lista de autores - Kirby's comics</title>");
		out.println("</head>");
		out.println("<body>");
		// cabecera
		out.println("<p><table align=\"center\" cellpadding=\"10\">" +
						"<tr align=\"center\">" +
							"<td ><img src=\"kirby.jpg\" width=\"150\" height=\"150\"></td>" +
							"<td ><h1 style=\"text-align:center;\"> Kirby's Comics </h1></td>" +
						"</tr>" +
					"</table>");
		out.println("<h3 style=\"text-align:center;\">Lista de autores con c�mics en nuestra tienda</h3>");
		out.println("<ul >");
		// Listamos autores.
		for(String autor : autores) {
			out.println("<li >"+autor+"</br>");
		}
		out.println("</ul>");
		out.println("<a href=\"index.html\">Volver a p�gina principal</a>");
		out.println("</body>");
		out.println("</html>");
	}
}

package controlador;

/**
 * @author Reflex
 *
 */
public class ComicStrings {

	
	/**
	 * Obtiene el c�digo del c�mic a partir de una cadena de un c�mic.
	 * 
	 * @param cadenaComic
	 * @return el c�digo del c�mic.
	 */
	public static String getCodigo(String cadenaComic) {
		int inicio = cadenaComic.indexOf("[cod=") + 5;
		int fin    = cadenaComic.indexOf(", tit=");
		return cadenaComic.substring(inicio, fin);
	}
	
	/**
	 * Obtiene el t�tulo del c�mic a partir de una cadena de un c�mic.
	 * 
	 * @param cadenaComic
	 * @return el t�tulo del c�mic o la cadena vac�a si el par�metro no es correcto.
	 */
	public static String getTitulo(String cadenaComic) {
		try {
			int inicio = cadenaComic.indexOf(", tit=") + 6;
			int fin    = cadenaComic.indexOf(", aut=");
			return cadenaComic.substring(inicio, fin);
		} catch(Exception e) {
			return "";
		}
	}
	
	/**
	 * Obtiene el autor del c�mic a partir de una cadena de un c�mic.
	 * 
	 * @param cadenaComic
	 * @return el autor del c�mic.
	 */
	public static String getAutor(String cadenaComic) {
		int inicio = cadenaComic.indexOf(", aut=") + 6;
		int fin    = cadenaComic.indexOf(", cant=");
		return cadenaComic.substring(inicio, fin);
	}
	
	/**
	 * Obtiene el stock del c�mic a partir de una cadena de un c�mic.
	 * 
	 * @param cadenaComic
	 * @return el stock del c�mic.
	 */
	public static int getStockRestante(String cadenaComic) {
		int inicio = cadenaComic.indexOf(", cant=") + 7;
		int fin    = cadenaComic.indexOf(", prec=");
		return Integer.parseInt(cadenaComic.substring(inicio, fin));
	}
	
	/**
	 * Obtiene el precio del c�mic a partir de una cadena de un c�mic.
	 * 
	 * @param cadenaComic
	 * @return el precio del c�mic.
	 */
	public static float getPrecio(String cadenaComic) {
		int inicio = cadenaComic.indexOf(", prec=") + 7;
		int fin    = cadenaComic.lastIndexOf("]");
		return Float.parseFloat(cadenaComic.substring(inicio, fin));
	}
}

package controlador;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.GestorConsultas;

/**
 * Servlet implementation class ServletBuscarComics
 * Permite, dado un nombre de autor, listar en una nueva p�gina web din�mica
 * los c�mics registrados en la tienda de dicho autor.
 */
public class ServletBuscarComics extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	// Gestor de consultas.
	private GestorConsultas gestor;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServletBuscarComics() {
		super();
		// Abrimos un gestor de consultas.
		gestor = new GestorConsultas("Kirbys.kbs");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 * 
	 * Genera din�micamente una p�gina web con una lista de los c�mics del autor.
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Obtenemos el nombre del autor introducido por el usuario en el formulario.
		String autor = request.getParameter("autor");
		// Buscamos los c�mics del autor en el gestor abierto anteriormente.
		String[] comics = gestor.buscaAutor(autor);
		
		// Fijamos el contenido de la p�gina web y escribimos la respuesta
		// en el objeto HttpServletResponse.
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println("<html>");
		out.println("<head>");
		out.println("<title>C�mics de " + autor + "</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<p><table align=\"center\" cellpadding=\"10\">" +
				"<tr align=\"center\">" +
					"<td ><img src=\"kirby.jpg\" width=\"150\" height=\"150\"></td>" +
					"<td ><h1 style=\"text-align:center;\"> Kirby's Comics </h1></td>" +
				"</tr>" +
			"</table>");
		out.println("<h3 style=\"text-align:center;\">C�mics de " + autor + "</h3>");
		out.println("<ul>");
		// Si no hay ning�n c�mic en el vector, mostramos un aviso de que
		// el autor introducido no tiene c�mics en nuestra tienda.
		if(comics.length == 0) {
			out.println(autor + " no tiene c�mics en nuestra tienda.");
		// Si contiene alg�n c�mic, listamos todos los que tenga.
		} else {
			out.println("<p><table align=\"center\" cellpadding=\"10\">");
			out.println(
					"<tr align=\"center\">" +
						//"<td ><img src=\"kirby.jpg\" width=\"150\" height=\"150\"></td>" +
						"<th > C�digo </th>" +
						"<th > T�tulo </th>" +
						"<th > Precio </th>" +
						"<th > Stock en tienda </th>" +
					"</tr>");
			for(String comic : comics) {
				float precio = ComicStrings.getPrecio(comic);
				String nombre = ComicStrings.getTitulo(comic);
				int stockRest = ComicStrings.getStockRestante(comic);
				String codigo = ComicStrings.getCodigo(comic);
				out.println(
						"<tr align=\"center\">" +
							//"<td ><img src=\"kirby.jpg\" width=\"150\" height=\"150\"></td>" +
							"<td >" + codigo + "</td>" +
							"<td >" + nombre + "</td>" +
							"<td >" + precio + "</td>" +
							"<td >" + stockRest + "</td>" +
						"</tr>");
			}
			out.println("</table>");
		}
		out.println("</ul>");
		out.println("<a href=\"index.html\">Volver a p�gina principal</a>");
		out.println("</body>");
		out.println("</html>");
	}

}

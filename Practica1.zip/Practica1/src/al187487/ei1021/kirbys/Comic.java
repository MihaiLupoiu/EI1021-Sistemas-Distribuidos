package al187487.ei1021.kirbys;

import java.io.EOFException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Serializable;
import java.util.Scanner;

// imports

public class Comic implements Serializable {
    /**
	 * Clase que permite escribir y leer un Comic de teclado y en un fichero de acceso directo 
	 */
	private static final long serialVersionUID = 1L;
	
	// atributos
	private int codigo;
	private String titulo;
	private String autor;
	private double precio;
	private int stock;
  

	/**
	 * Constructor de un C�mic con argumentos
	 * @param	codigo		c�digo del c�mic
	 * @param	titulo		t�tulo del c�mic
	 * @param	autor		autor del c�mic
	 * @param	precio		precio del c�mic
	 * @param	cantidad	ejemplares disponibles del c�mic
	 */	
  	public Comic(int codigo, String titulo, String autor, double precio, int cantidad) {
  		super();
		this.codigo = codigo;
		this.titulo = titulo;
		this.autor = autor;
		this.precio = precio;
		this.stock = cantidad;
  	}  // fin de constructor con argumentos
  	
  	public Comic(RandomAccessFile stream) {
  		try {
			leeDeFichero(stream);
		} catch (EOFException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
  	}

  	
	public int getCodigo() {
		return codigo;
	}


	public String getTitulo() {
		return titulo;
	}


	public String getAutor() {
		return autor;
	}


	public double getPrecio() {
		return precio;
	}


	public int getStock() {
		return stock;
	}
	
	public void a�adeEjemplar() {
		stock += 1;
	}
	
	public void quitaEjemplar() {
		stock -= 1;
	}


	/**
	 * Escribe los datos de un c�mic en una cadena y la devuelve
	 * @return	cadena con los datos del c�mic
	 */	
  	@Override
  	public String toString() {
        String str = "[";
        str += "cod=" + this.codigo + ", ";
        str += "tit=" + this.titulo + ", ";
        str += "aut=" + this.autor + ", ";
        str += "cant=" + this.stock + ", ";
        str += "prec=" + this.precio + "]";
        
        return str;
  	} // fin de toString

	/**
	 * Lee los datos de un c�mic de un stream de entrada
	 */	
  	public void leeDeTeclado(Scanner teclado) {
  		System.out.println("Introduce el c�digo del c�mic: ");
  		this.codigo = teclado.nextInt();
  		System.out.println("Introduce el t�tulo: ");
  		this.titulo = teclado.next();
  		System.out.println("Introduce el nombre del autor: ");
  		this.autor = teclado.next();
  		System.out.println("Introduce el precio: ");
  		this.precio = teclado.nextDouble();
  		System.out.println("Introduce la cantidad d ejemplares disponibles: ");
  		this.stock = teclado.nextInt();
  	} // fin leeDeTeclado
  	
	/**
	 * Escribe los datos de un c�mic en la posici�n actual de un fichero
	 * @param	stream	stream asociado al fichero
	 */	
  	public void escribeEnFichero(RandomAccessFile stream) {
  		try {
			stream.writeInt(this.codigo);
			stream.writeUTF(titulo);
			stream.writeUTF(autor);
			stream.writeDouble(precio);
			stream.writeInt(stock);
		} catch (IOException e) {
			e.printStackTrace();
		}
    } // fin escribeEnFichero
	
	/**
	 * Lee los datos de un c�mic de la posici�n actual de un fichero
	 * @param	stream	stream asociado al fichero
	 * @throws	EOFException, IOException
	 */	
  	public void leeDeFichero(RandomAccessFile stream) throws EOFException, IOException {
  		this.codigo = stream.readInt();
  		this.titulo = stream.readUTF();
  		this.autor = stream.readUTF();
  		this.precio = stream.readDouble();
  		this.stock = stream.readInt();
    } // fin leeComicDeFichero
  	
  	
}

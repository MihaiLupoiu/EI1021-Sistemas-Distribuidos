package al187487.ei1021.kirbys;

import java.util.Scanner;

// imports

public class PruebaTiendaLocal {

	private static int menu(){
		int opcion;
		Scanner teclado = new Scanner(System.in);

		do{
			//Menu
			System.out.println("\n1. Listar autores.");
			System.out.println("2. Buscar autor y mostrar sus c�mics");
			System.out.println("3. Comprar un c�mic");
			System.out.println("4. Revender c�mic");
			System.out.println("\n0. Salir");
			System.out.println("\nElige una opcion: ");
			//Lee nuestra opcion
			opcion = teclado.nextInt();
		}
		while (opcion < 0 || opcion > 4); //Hace el "do" mientras opcion no esta entre 0 y 4
		
		teclado.close();
		return opcion;//Devuelve la opcion.
	}
	private static void gestionarOP1(GestorConsultas gestor){
		for(String autor : gestor.listaAutores()){
			System.out.println(autor);
		}
	}
	private static void gestionarOP2(GestorConsultas gestor){
		String [] vector = gestor.buscaAutor(pedirNombre());
		if(vector.length != 0){
			for(String comic : vector){
				System.out.println(comic);
			}
		}else{
			System.out.println("\nNo se ha encontrado el autor, sigue intentando.");
		}
	}
	private static void gestionarOP3(GestorConsultas gestor){
		System.out.println(gestor.bajaComic(pedirCodigo()));
	}
	private static void gestionarOP4(GestorConsultas gestor){
		System.out.println(gestor.altaComic(pedirCodigo()));
	}
	private static String pedirNombre(){
		Scanner nombre = new Scanner(System.in);
		System.out.println("Introduce el nombre del autor: ");
		String str = nombre.nextLine();
		nombre.close();
		return str;
		
	}
	private static int pedirCodigo(){
		Scanner codigo = new Scanner(System.in);
		System.out.println("Introduce el codigo del c�mic: ");
		int cdg = codigo.nextInt();
		codigo.close();
		return cdg;
	}
	public static void main(String[] args) throws ClassNotFoundException {
		GestorConsultas gestor = new GestorConsultas("Ficheros/Kirbys.kbs");
		//Empieza el menu
		int opcion_menu;
		do{
			opcion_menu = menu();
			//Saca el menu por pantalla y lee por teclado la opcion

			if (opcion_menu == 1) {
				gestionarOP1(gestor);
				
			}else if(opcion_menu == 2){
				gestionarOP2(gestor);
			}else if(opcion_menu == 3){
				gestionarOP3(gestor);
			}else if(opcion_menu == 4){
				gestionarOP4(gestor);
			}
		}while(opcion_menu != 0);
		
		gestor.cierraGestor();
	}

}

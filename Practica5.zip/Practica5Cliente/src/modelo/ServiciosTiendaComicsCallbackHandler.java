
/**
 * ServiciosTiendaComicsCallbackHandler.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.2  Built on : Apr 17, 2012 (05:33:49 IST)
 */

    package modelo;

    /**
     *  ServiciosTiendaComicsCallbackHandler Callback class, Users can extend this class and implement
     *  their own receiveResult and receiveError methods.
     */
    public abstract class ServiciosTiendaComicsCallbackHandler{



    protected Object clientData;

    /**
    * User can pass in any object that needs to be accessed once the NonBlocking
    * Web service call is finished and appropriate method of this CallBack is called.
    * @param clientData Object mechanism by which the user can pass in user data
    * that will be avilable at the time this callback is called.
    */
    public ServiciosTiendaComicsCallbackHandler(Object clientData){
        this.clientData = clientData;
    }

    /**
    * Please use this constructor if you don't want to set any clientData
    */
    public ServiciosTiendaComicsCallbackHandler(){
        this.clientData = null;
    }

    /**
     * Get the client data
     */

     public Object getClientData() {
        return clientData;
     }

        
           /**
            * auto generated Axis2 call back method for listaAutores method
            * override this method for handling normal response from listaAutores operation
            */
           public void receiveResultlistaAutores(
                    modelo.ServiciosTiendaComicsStub.ListaAutoresResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from listaAutores operation
           */
            public void receiveErrorlistaAutores(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for buscaAutor method
            * override this method for handling normal response from buscaAutor operation
            */
           public void receiveResultbuscaAutor(
                    modelo.ServiciosTiendaComicsStub.BuscaAutorResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from buscaAutor operation
           */
            public void receiveErrorbuscaAutor(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for compraComic method
            * override this method for handling normal response from compraComic operation
            */
           public void receiveResultcompraComic(
                    modelo.ServiciosTiendaComicsStub.CompraComicResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from compraComic operation
           */
            public void receiveErrorcompraComic(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for vendeComic method
            * override this method for handling normal response from vendeComic operation
            */
           public void receiveResultvendeComic(
                    modelo.ServiciosTiendaComicsStub.VendeComicResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from vendeComic operation
           */
            public void receiveErrorvendeComic(java.lang.Exception e) {
            }
                


    }
    
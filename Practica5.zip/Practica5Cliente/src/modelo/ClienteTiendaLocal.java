package modelo;

import java.rmi.RemoteException;
import java.util.Scanner;

// imports

public class ClienteTiendaLocal {
	
	// Scanner que utilizaremos para leer de teclado.
	static Scanner teclado = new Scanner(System.in);

	
	/**
	 * M�todo que muestra las opciones del men� por pantalla y devuelve el c�digo introducido
	 * por el usuario.
	 * 
	 * @return El c�digo seleccionado.
	 */
	private static int menu(){
		int opcion = -1;
		boolean esNum = false;
		do {
			try {
				//Menu
				System.out.println("\n1. Listar autores.");
				System.out.println("2. Buscar autor y mostrar sus c�mics");
				System.out.println("3. Comprar un c�mic");
				System.out.println("4. Revender c�mic");
				System.out.println("\n0. Salir");
				System.out.println("\nElige una opcion: ");
				//Lee nuestra opcion
				opcion = teclado.nextInt();
				esNum = true;
			} catch(Exception e){
				System.out.println("No has introducido un c�digo v�lido.");
			} finally {
				// Limpiamos el escaner.
				teclado.nextLine();
			}
		} while(!esNum || opcion < 0 || opcion > 4);//Hace el "do" mientras opcion no esta entre 0 y 4
		
		return opcion;//Devuelve la opcion.
	}
	
	/**
	 * Gestionamos la opci�n primera: lista los autores de la tienda.
	 * 
	 * @param stub - Instancia de la clase stub, a partir de la cual invocaremos el servicio.
	 * @throws RemoteException
	 */
	private static void gestionarOP1(ServiciosTiendaComicsStub stub) throws RemoteException {
		// Creamos la petici�n.
		ServiciosTiendaComicsStub.ListaAutores req = new ServiciosTiendaComicsStub.ListaAutores();
		// Obtenemos la respuesta invocando al servicio.
		ServiciosTiendaComicsStub.ListaAutoresResponse res = stub.listaAutores(req);
		String[] listaAutores = res.get_return();
		// Imprimimos los autores.
		for(String autor : listaAutores){
			System.out.println(autor);
		}
	}
	
	/**
	 * Gestionamos la opci�n segunda: listar los c�mics de un autor.
	 * 
	 * @param stub - Instancia de la clase stub, a partir de la cual invocaremos el servicio.
	 * @throws RemoteException
	 */
	private static void gestionarOP2(ServiciosTiendaComicsStub stub) throws RemoteException {
		//Creamos la petici�n y definimos los par�metros.
		ServiciosTiendaComicsStub.BuscaAutor req = new ServiciosTiendaComicsStub.BuscaAutor();
		req.setAutorBuscado(pedirNombre());
		// Obtenemos la respuesta invocando al servicio.
		ServiciosTiendaComicsStub.BuscaAutorResponse res = stub.buscaAutor(req);
		String [] vector = res.get_return();
		// Imprimimos los c�mics.
		if(vector != null){
			for(String comic : vector){
				System.out.println(comic);
			}
		}else{
			System.out.println("\nNo se ha encontrado el autor, sigue intentando.");
		}
	}
	
	/**
	 * Gestionamos la opci�n tercera: comprar un c�mic a partir del c�digo.
	 * 
	 * @param stub - Instancia de la clase stub, a partir de la cual invocaremos el servicio.
	 * @throws RemoteException
	 */
	private static void gestionarOP3(ServiciosTiendaComicsStub stub) throws RemoteException {
		//Creamos la petici�n y definimos los par�metros.
		ServiciosTiendaComicsStub.CompraComic req = new ServiciosTiendaComicsStub.CompraComic();
		req.setCodigo(pedirCodigo());
		// Obtenemos la respuesta invocando al servicio.
		ServiciosTiendaComicsStub.CompraComicResponse res = stub.compraComic(req);
		String comic = res.get_return();
		// Imprimimos la compra.
		System.out.println(comic);
	}
	
	/**
	 * Gestionamos la opci�n cuarta: revender un c�mic a partir del c�digo.
	 * 
	 * @param stub - Instancia de la clase stub, a partir de la cual invocaremos el servicio.
	 * @throws RemoteException
	 */
	private static void gestionarOP4(ServiciosTiendaComicsStub stub) throws RemoteException {
		//Creamos la petici�n y definimos los par�metros.
		ServiciosTiendaComicsStub.VendeComic req = new ServiciosTiendaComicsStub.VendeComic();
		req.setCodigo(pedirCodigo());
		// Obtenemos la respuesta invocando al servicio.
		ServiciosTiendaComicsStub.VendeComicResponse res = stub.vendeComic(req);
		String comic = res.get_return();
		// Imprimimos la venta.
		System.out.println(comic);
	}
	
	/**
	 * M�todo que pide por teclado un nombre de autor al usuario. 
	 * 
	 * @return un String con el nombre introducido.
	 */
	private static String pedirNombre(){
		System.out.println("Introduce el nombre del autor: ");
		String str = teclado.nextLine();
		return str;
	}
	
	/**
	 * M�todo que pide por teclado un c�digo de c�mic.
	 * 
	 * @return un entero con el nombre introducido.
	 */
	private static int pedirCodigo(){
		//Scanner codigo = new Scanner(System.in);
		boolean esNum = false;
		int cdg = -1;
		do {
			try {
				System.out.println("Introduce el codigo del c�mic: ");
				cdg = teclado.nextInt();
				esNum = true;
			} catch(Exception e){
				System.out.println("No has introducido un c�digo v�lido.");
			} finally {
				// Limpiamos el escaner.
				teclado.nextLine();
			}
		} while(!esNum);
		return cdg;
	}
	
	public static void main(String[] args) throws ClassNotFoundException {
		try {
			// Creamos la instancia del stub.
			ServiciosTiendaComicsStub stub = new ServiciosTiendaComicsStub();
			
			//Empieza el menu
			int opcion_menu;
			do{
				opcion_menu = menu();
				// Saca el menu por pantalla y lee por teclado la opcion.
				if (opcion_menu == 1) {
					gestionarOP1(stub);
					
				} else if(opcion_menu == 2) {
					gestionarOP2(stub);
					
				} else if(opcion_menu == 3) {
					gestionarOP3(stub);

				} else if(opcion_menu == 4) {
					gestionarOP4(stub);
				}
				
			} while(opcion_menu != 0);
			
		} 
		catch (RemoteException e) {
			e.printStackTrace();
		} 
		finally {
			// Cerramos el Scanner en cualquier caso.
			System.out.println("Cerrando el scanner...");
			teclado.close();
			System.out.println("Fin del programa.");
		}
	}

}

package modelo;

public class ServiciosTiendaComics {
	
	private GestorConsultas gestor;
	
	
	public ServiciosTiendaComics() {
		gestor = new GestorConsultas("skirbys.kbs");
	}
	
//===========================================================================
	public String[] listaAutores() {
		return gestor.listaAutores();
	}
	
	public String[] buscaAutor( String autorBuscado ) {
		return gestor.buscaAutor(autorBuscado);
	}
	
	public String compraComic( int codigo) {
		return gestor.bajaComic(codigo);
	}
	
	public String vendeComic( int codigo) {
		return gestor.altaComic(codigo);
	}
//============================================================================
}
package al187487.ei1021.kirbys.rmi.server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import al187487.ei1021.kirbys.GestorConsultas;
import al187487.ei1021.kirbys.rmi.common.IntServidorTiendaRMI;

/**
 * @author Aar�n Nadal y Mihaita Lupoiu - 01.11.2012
 * 
 */
public class ImplServidorTiendaRMI extends UnicastRemoteObject implements IntServidorTiendaRMI {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5774108542858370335L;
	
	private GestorConsultas gestor = new GestorConsultas("ficheros/Kirbys.kbs");
	
	public ImplServidorTiendaRMI() throws RemoteException {
		super();
	}
	
	@Override
	public Set<String> listaAutores() throws RemoteException{
		String[] autores = gestor.listaAutores();
		HashSet<String> conjuntoAutores =new HashSet<String>(autores.length);
		for(String autor:autores){
			conjuntoAutores.add(autor);
		}
		return conjuntoAutores;
	}

	@Override
	public List<String> buscaAutor(String nombre) throws RemoteException{
		String [] comics = gestor.buscaAutor(nombre);
		List<String> listaComics = new ArrayList<String>(comics.length);
		if(comics.length != 0){
			for(String comic : comics){
				listaComics.add(comic);
			}
			return listaComics;
		}
		return null;
	}

	@Override
	public String compraComic(int codigo) throws RemoteException{
		return gestor.bajaComic(codigo);
	}

	@Override
	public String vendeComic(int codigo) throws RemoteException{
		return gestor.altaComic(codigo);
	}

}

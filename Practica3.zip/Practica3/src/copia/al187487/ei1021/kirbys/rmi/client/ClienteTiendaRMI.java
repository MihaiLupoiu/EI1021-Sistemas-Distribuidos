package copia.al187487.ei1021.kirbys.rmi.client;

import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import copia.al187487.ei1021.kirbys.rmi.common.IntCallbackCliente;
import copia.al187487.ei1021.kirbys.rmi.common.IntServidorTiendaRMI;

/**
 * @author Aar�n Nadal y Mihaita Lupoiu - 01.11.2012
 * 
 */
public class ClienteTiendaRMI {

	public static void main(String[] args) {
		// Puerto y url por defecto.
		int puerto = 1099;
		String URLreg = "rmi://localhost:" + puerto + "/kirbysRMI";
		
		IntServidorTiendaRMI str;
		IntCallbackCliente clbck;

		try {
			// start a security manager - this is needed if
			// stub downloading is in use for this application.
			System.setSecurityManager(new RMISecurityManager());
						
			// Obtenemos el objeto remoto.
			str = (IntServidorTiendaRMI) Naming.lookup(URLreg);
			clbck = new ImplCallbackCliente();

			int opcion_menu;
			do{
				opcion_menu = menu();
				//Saca el menu por pantalla y lee por teclado la opcion
				if (opcion_menu == 1) {
					gestionarOP1(str);
				}else if(opcion_menu == 2){
					gestionarOP2(str);
				}else if(opcion_menu == 3){
					gestionarOP3(str);
				}else if(opcion_menu == 4){
					gestionarOP4(str);
				}else if(opcion_menu == 5){
					gestionarOP5(str, clbck);
				}else if(opcion_menu == 6){
					gestionarOP6(str, clbck);
				}
			// Si se introduce la opci�n 0, el programa finaliza.
			}while(opcion_menu != 0);
			
			// Cuando el cliente sale del programa, se elimina autom�ticamente su registro.
			gestionarOP6(str, clbck);
			
		} catch (Exception e) {
			System.out.println("Exception en Cliente Tienda RMI");
			e.printStackTrace();
			System.exit(-1);
		}
	}

	/**
	 * Gestiona la opci�n 1, lista los autores.
	 * 
	 * @param gestor Objeto remoto.
	 */
	private static void gestionarOP1(IntServidorTiendaRMI gestor){
		try {
			for(String autor : gestor.listaAutores()){
				System.out.println(autor);
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Gestiona la opci�n 2, muestra los comics de un autor que el usuario introduce por
	 * teclado.
	 * 
	 * @param gestor Objeto remoto.
	 */
	private static void gestionarOP2(IntServidorTiendaRMI gestor){
		List<String> vector = new ArrayList<String>();
		try {
			vector = gestor.buscaAutor(pedirNombre());
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		if(vector.size() != 0){
			for(String comic : vector){
				System.out.println(comic);
			}
		}else{
			System.out.println("\nNo se ha encontrado el autor, sigue intentando.");
		}
	}
	
	/**
	 * Gestiona la opci�n 3, compra un c�mic a partir de un c�digo de c�mic que el usuario
	 * introduce por teclado.
	 * 
	 * @param gestor Objeto remoto.
	 */
	private static void gestionarOP3(IntServidorTiendaRMI gestor){
		try {
			System.out.println(gestor.compraComic(pedirCodigo()));
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Gestiona la opci�n 4, vende un c�mic a partir de un c�digo de c�mic que el usuario
	 * introduce por teclado.
	 * 
	 * @param gestor Objeto remoto.
	 */
	private static void gestionarOP4(IntServidorTiendaRMI gestor){
		try {
			System.out.println(gestor.vendeComic(pedirCodigo()));
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Gestiona la opci�n 5, registra a un usuario para recibir callbacks.
	 * 
	 * @param gestor Objeto remoto.
	 */
	private static void gestionarOP5(IntServidorTiendaRMI gestor, IntCallbackCliente clbck){
		try {
			if(gestor.registrarCallback(clbck)) {
				System.out.println("Registro completado.");
			}
			else {
				System.out.println("Registro incompleto: el cliente ya est� registrado.");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Gestiona la opci�n 6, elimina el registro de un usuario para que ya no
	 * reciba m�s callbacks.
	 * 
	 * @param gestor Objeto remoto.
	 */
	private static void gestionarOP6(IntServidorTiendaRMI gestor, IntCallbackCliente clbck){
		try {
			// Si el usuario est� en el registro se borra, si no se lanza una advertencia.
			if(gestor.eliminarRegistroCallback(clbck)) {
				System.out.println("Registro eliminado.");
			} else {
				System.out.println("No se puede borrar el registro. El cliente no est� registrado.");
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Pide un nombre de autor por teclado al usuario. 
	 * 
	 * @return El nombre introducido por el usuario.
	 */
	private static String pedirNombre(){
		Scanner nombre = new Scanner(System.in);
		System.out.println("Introduce el nombre del autor: ");
		return nombre.nextLine();
	}
	
	/**
	 * Pide un c�digo de c�mic por teclado al usuario. 
	 * 
	 * @return El c�digo introducido por el usuario.
	 */
	private static int pedirCodigo(){
		Scanner codigoC = new Scanner(System.in);
		System.out.println("Introduce el codigo del c�mic: ");
		return codigoC.nextInt();
	}

	/**
	 * Mestra el men� y devuelve una opci�n elegida por el usuario.
	 * 
	 * @return Opci�n elegida.
	 */
	private static int menu(){
		int opcion;
		Scanner teclado = new Scanner(System.in);

		do{
			//Menu
			System.out.println("\n1. Listar autores.");
			System.out.println("2. Buscar autor y mostrar sus c�mics");
			System.out.println("3. Comprar un c�mic");
			System.out.println("4. Revender c�mic");
			System.out.println("5. Registrarse a notificaciones");
			System.out.println("6. Borrar registro a notificaciones");
			System.out.println("\n0. Salir");
			System.out.println("\nElige una opcion: ");
			//Lee nuestra opcion
			opcion = teclado.nextInt();
		}
		while (opcion < 0 || opcion > 6);//Hace el "do" mientras opcion esta entre 0 y 4
		
		return opcion;//Devuelve la opcion.
	}
}

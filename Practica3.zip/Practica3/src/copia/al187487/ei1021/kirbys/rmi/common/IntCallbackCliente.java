package copia.al187487.ei1021.kirbys.rmi.common;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * @author Aar�n Nadal y Mihaita Lupoiu - 01.11.2012
 * 
 */
public interface IntCallbackCliente extends Remote {

	/**
	 * M�todo al que llamar� el servidor cuando disponga de stock de alg�n c�mic
	 * nuevo para avisar al cliente.
	 */
	public String notificaNuevaVenta(String mensaje) throws RemoteException;

}

package copia.al187487.ei1021.kirbys.rmi.server;

import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 * @author Aar�n Nadal y Mihaita Lupoiu - 01.11.2012
 * 
 */
public class ServidorTiendaRMI  {
	public static void main(String args[]) {
		// Puerto y url por defecto.
		int puerto = 1099;
		String URLreg = "rmi://localhost:" + puerto + "/kirbysRMI";
		System.out.println("Iniciando Servidor Tienda RMI");
		
		try {
			// start a security manager - this is needed if
			// stub downloading is in use for this application.
			System.setSecurityManager(new RMISecurityManager());
			
			// Inicia el registro.
			startRegistry(puerto);
			// Crea la entrada del objeto remoto en el registro.
			ImplServidorTiendaRMI istr = new ImplServidorTiendaRMI();
			Naming.rebind(URLreg, istr);
			System.out.println("Servidor Tienda RMI Iniciado");
		} catch (Exception e) {
			System.out.println("Exception in Servidor Tienda RMI");
			e.printStackTrace();
		}
	}
		
	
	/**
	 * Inicia el registro si existe, y si no lo crea.
	 * 
	 * @param puerto - Puerto sobre el que se iniciar� el registro.
	 * @throws RemoteException
	 */
	private static void startRegistry(int puerto) throws RemoteException{
		try{
			Registry reg = LocateRegistry.getRegistry(puerto);
			reg.list();
		}catch(RemoteException e){
			LocateRegistry.createRegistry(puerto);
		}
	}
	
}

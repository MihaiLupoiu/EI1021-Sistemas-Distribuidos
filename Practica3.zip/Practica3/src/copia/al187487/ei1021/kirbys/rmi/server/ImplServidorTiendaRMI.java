package copia.al187487.ei1021.kirbys.rmi.server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import copia.al187487.ei1021.kirbys.GestorConsultas;
import copia.al187487.ei1021.kirbys.rmi.common.IntCallbackCliente;
import copia.al187487.ei1021.kirbys.rmi.common.IntServidorTiendaRMI;

/**
 * @author Aar�n Nadal y Mihaita Lupoiu - 01.11.2012
 * 
 */
public class ImplServidorTiendaRMI extends UnicastRemoteObject implements IntServidorTiendaRMI {

	private Vector<IntCallbackCliente> registroCallback = new Vector<IntCallbackCliente>();
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5774108542858370335L;
	
	private GestorConsultas gestor = new GestorConsultas("ficheros/Kirbys.kbs");
	
	public ImplServidorTiendaRMI() throws RemoteException {
		super();
	}
	
	@Override
	public Set<String> listaAutores() throws RemoteException{
		String[] autores = gestor.listaAutores();
		HashSet<String> conjuntoAutores =new HashSet<String>(autores.length);
		for(String autor:autores){
			conjuntoAutores.add(autor);
		}
		return conjuntoAutores;
	}

	@Override
	public List<String> buscaAutor(String nombre) throws RemoteException{
		String [] comics = gestor.buscaAutor(nombre);
		List<String> listaComics = new ArrayList<String>(comics.length);
		if(comics.length != 0){
			for(String comic : comics){
				listaComics.add(comic);
			}
			return listaComics;
		}
		return null;
	}

	@Override
	public String compraComic(int codigo) throws RemoteException{
		return gestor.bajaComic(codigo);
	}

	@Override
	public String vendeComic(int codigo) throws RemoteException{
		String comic = gestor.altaComic(codigo);
		hacerCallbacksNuevaVenta(comic);
		return comic;
	}

	/**
	 * Hemos a�adido un par�metro a la funcion del ejemplo para que el cliente
	 * sepa con exactitud el c�mic del que se ha recibido nuevo stock.
	 * 
	 * @param codigo Codigo del c�mic del que se ha recibido nuevo stock
	 */
	private synchronized void hacerCallbacksNuevaVenta(String comic) {
		List<IntCallbackCliente> clientesAusentes = new LinkedList<IntCallbackCliente>();
		for(IntCallbackCliente cliente : registroCallback) {
			try {
				cliente.notificaNuevaVenta("Nuevo c�mic disponible:\n"+comic);
			} catch (RemoteException e) {
				// Aqu� gestionamos la excepci�n en caso de que un ciente registrado
				// ya no est� en ejecuci�n o conectado al servidor.
				System.out.println("Fallo al hacer el callback de cliente.");
				clientesAusentes.add(cliente);
				System.out.println("Cliente eliminado del registro de callbacks");
			}
		}
		// Aqu� borramos los clientes a los que no se les ha podido realizar el callback
		for(IntCallbackCliente c : clientesAusentes)
			registroCallback.removeElement(c);
	}

	@Override
	public synchronized boolean registrarCallback(IntCallbackCliente objCliente)
			throws RemoteException {
		// A�adimos el cliente al registro si la entrada no existe.
		if(! registroCallback.contains(objCliente)) {
			registroCallback.addElement(objCliente);
			System.out.println("Nuevo cliente registrado.");
			return true;
		}
		return false;
	}

	@Override
	public synchronized boolean eliminarRegistroCallback(IntCallbackCliente objCliente)
			throws RemoteException {
		// Eliminamos al cliente del registro en el caso de que se encuentre en �l.
		if(registroCallback.removeElement(objCliente)) {
			System.out.println("Cliente eliminado correctamente.");
			return true;
		}
		else {
			System.out.println("El cliente no se ha encontrado en el registro.");
			return false;
		}
	}
}

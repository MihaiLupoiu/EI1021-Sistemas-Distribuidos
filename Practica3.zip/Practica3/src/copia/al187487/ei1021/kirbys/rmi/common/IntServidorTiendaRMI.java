package copia.al187487.ei1021.kirbys.rmi.common;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Set;

/**
 * @author Aar�n Nadal y Mihaita Lupoiu - 01.11.2012
 * 
 */
public interface IntServidorTiendaRMI extends Remote {
	/**
	 * Lista los autores disponibles en la tienda.
	 * 
	 * @return Un conjunto con los autores.
	 * @throws RemoteException
	 */
	public Set<String> listaAutores() throws RemoteException;
	
	/**
	 * Busca los c�mics de un autor disponibles en la tienda.
	 * 
	 * @param nombre Nombre del autor.
	 * @return Una lista de c�mics del autor.
	 * @throws RemoteException
	 */
	public List<String> buscaAutor(String nombre)throws RemoteException;
	
	/**
	 * Compra un c�mic a la tienda.
	 * 
	 * @param codigo C�digo del c�mic a comprar.
	 * @return Una cadena con la informaci�n del c�mic.
	 * @throws RemoteException
	 */
	public String compraComic(int codigo)throws RemoteException;
	
	/**
	 * Vende un c�mic a la tienda.
	 * 
	 * @param codigo C�digo del c�mic a vender.
	 * @return Una cadena con la informaci�n del c�mic.
	 * @throws RemoteException
	 */
	public String vendeComic(int codigo) throws RemoteException;
	
	/**
	 * Registra un nuevo cliente.
	 * 
	 * @param objCliente Cliente a registrar.
	 * @return true si se completa el registro y false si el usuario ya estaba registrado.
	 * @throws RemoteException
	 */
	public boolean registrarCallback(IntCallbackCliente objCliente) throws RemoteException;
	
	/**
	 * Elimina un cliente del registro de callbacks.
	 * 
	 * @param objCliente Cliente a borrar del registro.
	 * @return true si se elimina el registro y false si el usuario no estaba registrado.
	 * @throws RemoteException
	 */
	public boolean eliminarRegistroCallback(IntCallbackCliente objCliente) throws RemoteException;
}

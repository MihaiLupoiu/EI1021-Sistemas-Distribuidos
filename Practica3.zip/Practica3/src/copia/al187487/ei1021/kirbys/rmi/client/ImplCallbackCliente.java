package copia.al187487.ei1021.kirbys.rmi.client;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import copia.al187487.ei1021.kirbys.rmi.common.IntCallbackCliente;

/**
 * @author Aar�n Nadal y Mihaita Lupoiu - 01.11.2012
 * 
 */
public class ImplCallbackCliente extends UnicastRemoteObject implements IntCallbackCliente {

	protected ImplCallbackCliente() throws RemoteException {
		super();
	}

	@Override
	public String notificaNuevaVenta(String mensaje) throws RemoteException {
		System.out.println("Callback recibido: " + mensaje);
		return mensaje;
	}
}

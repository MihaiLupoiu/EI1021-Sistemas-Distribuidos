package copia.al187487.ei1021.kirbys;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Aar�n Nadal y Mihaita Lupoiu - 01.11.2012
 * 
 */
public class GestorConsultas {

	// atributos
	private RandomAccessFile stream;

	/**
	 * Constructor del gestor de consultas de la tienda.
	 * Abre el fichero con los datos de prueba.
	 * Si no existe, lo crea
	 */
	public GestorConsultas(String nombre) {
		creaFichero(nombre);
	}

	/**
	 * Dado un nombre de fichero, lo abre para Lectura/Escritura en caso de que exista, o lo crea en 
	 * cualquier otro caso.
	 * @param nombreFichero  nombre del fichero
	 */
	private void creaFichero(String nombreFichero) {
		try {
			stream = new RandomAccessFile(nombreFichero, "rw");
			if(stream.length() == 0){
				Comic c = new Comic(1, "Watchmen", "A. Moore", 20.0, 3);
				c.escribeEnFichero(stream);
				c = new Comic(2, "Akira", "K. Otomo", 130.0, 1);
				c.escribeEnFichero(stream);
				c = new Comic(3, "Bone", "J. Smith", 20.0, 10);
				c.escribeEnFichero(stream);
				c = new Comic(4, "The League of extraordinary gentlemen", "A. Moore", 50.0, 5);
				c.escribeEnFichero(stream);
				c = new Comic(4, "Barrio lejano", "J. Taniguchi", 35.0, 2);
				c.escribeEnFichero(stream);	
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Cierra el flujo/stream asociado al fichero de c�mics.
	 */
	public void cierraGestor(){
		try {
			stream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * M�todo auxiliar privado que busca un c�mic con un c�digo dado y devuelve su posici�n en el fichero
	 * Si no lo encuentra, devuelve -1
	 * @param	codigoBuscado	c�digo del c�mic buscado
	 * @return					byte de inicio del registro en el fichero
	 */
	private long buscaCodigo(int codigoBuscado) {
		long pos = -1;

		try {
			// nos movemos al inicio del fichero.
			stream.seek(0);
			while(pos == -1 && stream.getFilePointer() < stream.length()) {
				long posInicial = stream.getFilePointer();
				Comic comic = new Comic(stream);
				if(comic.getCodigo() == codigoBuscado) {
					pos = posInicial;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return pos;
	}

	/**
	 * Devuelve un vector con los autores de c�mics en el cat�logo de la tienda
	 * @return	Vector de cadenas con los autores
	 */
	public String[] listaAutores() {
		List <String> lista = new ArrayList<String>();
		try {
			stream.seek(0);
			while(stream.getFilePointer() < stream.length()){
				Comic comic = new Comic(stream);
				if(!lista.contains(comic.getAutor())){
					lista.add(comic.getAutor());
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		String [] listaA = new String [lista.size()];
		return lista.toArray(listaA);
	}


	/**
	 * Busca los c�mics de un determinado autor en el fichero y los devuelve como un vector de cadenas
	 * Si no hay ninguno, devuelve el vector vac�o
	 * @param	autorBuscado	autor del c�mic buscado
	 * @return					Vector de cadenas asociadas a los c�mics del autor
	 */
	public String[] buscaAutor(String autorBuscado) {
		List <String> lista = new ArrayList<String>();
		try {
			stream.seek(0);
			while(stream.getFilePointer() != stream.length()){
				Comic comic = new Comic(stream);
				if(comic.getAutor().equals(autorBuscado)){
					lista.add(comic.toString());
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		String [] listaA = new String [lista.size()];
		return lista.toArray(listaA);
	}

	/**
	 * Da de alta un ejemplar del c�mic con un c�digo dado y devuelve una cadena con sus datos
	 * Si el c�mic no estaba en el fichero, devuelve la cadena vac�a
	 * @param	codigoBuscado	codigo del c�mic buscado
	 * @return					cadena con informaci�n del c�mic
	 */
	public String altaComic(int codigoBuscado) {
		long pos = buscaCodigo(codigoBuscado);
		if(pos != -1) {
			try {
				stream.seek(pos);
			} catch (IOException e) {
				e.printStackTrace();
			}
			Comic comic = new Comic(stream);
			comic.anyadeEjemplar();
			try {
				stream.seek(pos);
			} catch (IOException e) {
				e.printStackTrace();
			}
			comic.escribeEnFichero(stream);
			return comic.toString();
		}
		return "\nNo se ha encontrado el c�mic.";
	}

	/**
	 * Da de baja un ejemplar del c�mic con un c�digo dado y devuelve una cadena con sus datos
	 * Si no hay ninguno, devuelve una cadena vac�a
	 * @param	codigo	codigo del c�mic buscado
	 * @return			cadena con informaci�n del c�mic
	 */
	public String bajaComic(int codigoBuscado) {
		long pos = buscaCodigo(codigoBuscado);
		if(pos != -1) {
			try {
				stream.seek(pos);
			} catch (IOException e) {
				e.printStackTrace();
			}
			Comic comic = new Comic(stream);
			if(comic.getStock() <= 0)
				return "\nNo nos queda stock de este c�mic.";
			
			comic.quitaEjemplar();
			try {
				stream.seek(pos);
			} catch (IOException e) {
				e.printStackTrace();
			}
			comic.escribeEnFichero(stream);
			return comic.toString();
		}
		return "\nNo se ha encontrado el c�mic.";
	}


}
